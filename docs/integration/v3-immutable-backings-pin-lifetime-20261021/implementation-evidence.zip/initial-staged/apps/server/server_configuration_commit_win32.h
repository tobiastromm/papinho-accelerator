#ifndef PAPACC_SERVER_CONFIGURATION_COMMIT_WIN32_H
#define PAPACC_SERVER_CONFIGURATION_COMMIT_WIN32_H
/* Private modern-Windows diagnostic component; not a configuration service.
 * Zeroed durable owner storage required. No network, PST or secret storage. */
#include <windows.h>
#include "server_config.h"
#define PAPACC_CONFIG_RECORD_BYTES 512U
#define PAPACC_CONFIG_STORE_BYTES 8192U
#ifdef PAPACC_C8_PRIVATE_STORAGE_PROFILE
#include "../../src/issuer/issuer_codec.h"
#include "server_configuration_pending_win32.h"
#define PAPACC_CONFIG_STORAGE_BYTES PAPACC_ISSUER_LINKED_ROOT_BYTES
#define PAPACC_CONFIG_COMMITTED_BYTES PAPACC_CONFIG_TRANSACTION_BYTES
#else
#define PAPACC_CONFIG_STORAGE_BYTES PAPACC_CONFIG_STORE_BYTES
#define PAPACC_CONFIG_COMMITTED_BYTES PAPACC_CONFIG_STORAGE_BYTES
#endif
#define PAPACC_CONFIG_SLOTS 3U
#define PAPACC_CONFIG_IDS 8U
typedef struct PAPACC_CONFIG_VIEW {
    PAPACC_SERVER_CONFIG config;
    PAPACC_NETWORK_INTERFACE_PERSISTENT_ID ids[PAPACC_CONFIG_IDS];
    unsigned char domain[32];
    PAPACC_U64 revision, predecessor, policy_epoch;
} PAPACC_CONFIG_VIEW;
typedef struct PAPACC_CONFIG_SLOT {
    PAPACC_CONFIG_VIEW view;
    unsigned long readers;
    PAPACC_U64 serial;
#ifdef PAPACC_C8_PRIVATE_STORAGE_PROFILE
    PAPACC_U64 context_epoch; /* A: same-root post-commit administrative context. */
    PAPACC_U64 operational_epoch; /* P: independently bound current C2 policy. */
    PAPACC_U64 issuer_revision; /* I: absent unless issuer_snapshot_valid. */
#endif
    int retained;
} PAPACC_CONFIG_SLOT;
typedef struct PAPACC_CONFIG_PIN {
    const void *issuer;
    unsigned index;
    PAPACC_U64 serial, ticket;
} PAPACC_CONFIG_PIN;
/* Private by-value DATA backing, same slots/tickets; never CURRENT or trust.
 * Full image owns SNT/PDG/issuer/BODY/policy references. CA is public DER only.
 * Selected Windows process reserves all three slots even when dormant. */
#if defined(PAPACC_C8_PRIVATE_STORAGE_PROFILE) && defined(PAPACC_ED11_WINDOWS_3MIB)
#define PAPACC_CONFIG_V3_CA_BYTES 8192U
typedef struct PAPACC_CONFIG_V3_BACKING {
 unsigned char packet[30592],ca[PAPACC_CONFIG_V3_CA_BYTES];
 unsigned char packet_hash[32],ca_hash[32];
 PAPACC_SIZE packet_bytes,ca_bytes;
 PAPACC_U64 serial; /* exact existing slot generation, not an epoch */
} PAPACC_CONFIG_V3_BACKING;
#endif
typedef struct PAPACC_CONFIGURATION_COMMIT {
    CRITICAL_SECTION lock;
    PAPACC_CONFIG_SLOT slots[PAPACC_CONFIG_SLOTS];
    PAPACC_CONFIG_PIN tickets[32];
    PAPACC_U64 next_ticket;
    unsigned char committed[PAPACC_CONFIG_COMMITTED_BYTES];
    char path[MAX_PATH];
    unsigned char domain[32];
    HANDLE retained_file, retained_transaction;
    DWORD writer;
    unsigned current, pending;
    PAPACC_U64 next_serial;
    int initialized, prepared, committed_pending, published, stopped, unresolved;
    int store02, recovery_selected;
#ifdef PAPACC_C8_PRIVATE_STORAGE_PROFILE
    PAPACC_CONFIG_PENDING pending_commit;
    DWORD committed_bytes; /* actual same-file size, not allocated capacity */
    int authority_lost; /* CAS conflict/unknown is not old CURRENT. */
    int recovery_guard; /* Exclusive native read lease, not Model E destruction. */
    unsigned char issuer_staged[PAPACC_ISSUER_IMAGE_BYTES];
    void *issuer_hash_alg,*issuer_hash;
    LONG issuer_hash_error;
    int issuer_stage_prepared;
    /* Immutable issuer bytes belong to the existing bounded config slots.
     * A pin protects the matching slot serial, never the mutable latest image. */
    unsigned char issuer_snapshots[PAPACC_CONFIG_SLOTS][PAPACC_ISSUER_IMAGE_BYTES];
    int issuer_snapshot_valid[PAPACC_CONFIG_SLOTS];
#if defined(PAPACC_ED11_WINDOWS_3MIB)
    PAPACC_CONFIG_V3_BACKING v3_backings[PAPACC_CONFIG_SLOTS];
#endif
#endif
} PAPACC_CONFIGURATION_COMMIT;
/* init only creates an in-memory diagnostic domain; CREATE_NEW at first commit
 * prevents replacing any existing installation. No recovery authorization. */
PAPACC_RESULT papacc_configuration_commit_init(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_prepare(PAPACC_CONFIGURATION_COMMIT *,
    const PAPACC_SERVER_CONFIG *,PAPACC_U64,PAPACC_U64);
PAPACC_RESULT papacc_configuration_commit(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_publish(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_abort(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_pin(PAPACC_CONFIGURATION_COMMIT *,PAPACC_CONFIG_PIN *,PAPACC_CONFIG_VIEW *);
PAPACC_RESULT papacc_configuration_unpin(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_CONFIG_PIN *,int);
PAPACC_BOOL papacc_configuration_current(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_CONFIG_VIEW *);
PAPACC_RESULT papacc_configuration_stop(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_finish(PAPACC_CONFIGURATION_COMMIT *);
/* Integrity inspection cannot authorize recovery. Output never contains a
 * usable view. Even a valid record returns NOT_SUPPORTED without continuity. */
PAPACC_RESULT papacc_configuration_recovery_inspect(PAPACC_CONFIGURATION_COMMIT *,const char *);
/* Opt-in protocol0.2 full server-model profile; no operational activation. */
PAPACC_RESULT papacc_configuration_commit_init02(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_recovery_init02(PAPACC_CONFIGURATION_COMMIT *,const char *);
/* Query-only candidate, NOT a published/current configuration or new grant. */
PAPACC_RESULT papacc_configuration_recovered_copy(PAPACC_CONFIGURATION_COMMIT *,PAPACC_CONFIG_VIEW *);
#ifdef PAPACC_C8_PRIVATE_STORAGE_PROFILE
/* Root must validate full CURRENT/projection before beginning publication checkpoint.
 * Same pending worker/CAS; this records historical facts, never recovery authority. */
PAPACC_RESULT papacc_configuration_checkpoint_begin07(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_checkpoint_poll07(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_CAS_RESULT *);
PAPACC_RESULT papacc_configuration_checkpoint_data07(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_LINK *);
PAPACC_RESULT papacc_configuration_issuer_begin06(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_issuer_poll06(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_CAS_RESULT *);
/* BODY0.3 is a COMPONENT store, not the application's normative commit.
 * No caller epoch accepted; zero records unavailable epoch, never a grant. */
PAPACC_RESULT papacc_configuration_commit_init03(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_recovery_init03(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_prepare03(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_SERVER_CONFIG *,PAPACC_U64);
/* Private isolated preserved-local-custody evidence. Integrity/file ID alone
 * do not establish freshness outside ADR0046's explicitly supervised scope. */
typedef struct PAPACC_NORMAL_RESTART_WITNESS {
 unsigned char domain[32], image_sha256[32];
 PAPACC_U64 revision, predecessor, volume, file_index;
} PAPACC_NORMAL_RESTART_WITNESS;
PAPACC_RESULT papacc_configuration_recovery_guard03(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_NORMAL_RESTART_WITNESS *);
PAPACC_RESULT papacc_configuration_recovery_validate03(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_recovery_publish03(PAPACC_CONFIGURATION_COMMIT *);
/* Private ROOT06 component, same file and owner. No normative/live CURRENT.
 * Caller must establish application dormancy; readers/retained slots deny.
 * Epoch and admission proofs are never inferred from stored issuer bytes. */
int papacc_configuration_issuer_hash06(void *,const PAPACC_U8 *,PAPACC_SIZE,PAPACC_U8[32]);
PAPACC_RESULT papacc_configuration_issuer_prepare06(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_U8 *,PAPACC_U64,PAPACC_U64);
PAPACC_RESULT papacc_configuration_issuer_copy06(PAPACC_CONFIGURATION_COMMIT *,PAPACC_U8 *);
/* Data-only copy using an existing live pin; no CURRENT/epoch proof returned. */
PAPACC_RESULT papacc_configuration_issuer_snapshot06(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_CONFIG_PIN *,PAPACC_U8 *);
PAPACC_RESULT papacc_configuration_issuer_recovery06(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_pin_read(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_CONFIG_PIN *,PAPACC_CONFIG_VIEW *,PAPACC_U64 *,PAPACC_U64 *);
/* Offline DATA inspection of a full historical carrier, not file adoption.
 * Caller owns immutable16384 input and disjoint workspace/output. No CURRENT,
 * epoch/proof bits, source lease, key binding or recovery authority returned.
 * Embedded file identity is checked for internal consistency only. */
PAPACC_RESULT papacc_configuration_issuer_carrier_inspect06(
 PAPACC_CONFIGURATION_COMMIT *,const PAPACC_U8 *,PAPACC_SIZE,
 PAPACC_CONFIG_VIEW *,PAPACC_ISSUER_VIEW *);
int papacc_configuration_issuer_projection06(const PAPACC_SERVER_CONFIG *,const PAPACC_SERVER_CONFIG *);
PAPACC_RESULT papacc_configuration_issuer_publish06(PAPACC_CONFIGURATION_COMMIT *);
/* Explicit BODY0.5 catalog profile; no old-format promotion. */
PAPACC_RESULT papacc_configuration_commit_init05(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_prepare05(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_SERVER_CONFIG *,PAPACC_U64);
/* Explicit typed0.4 profile;0.2/0.3 entry points remain strict. */
PAPACC_RESULT papacc_configuration_commit_init04(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_recovery_init04(PAPACC_CONFIGURATION_COMMIT *,const char *);
PAPACC_RESULT papacc_configuration_prepare04(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_SERVER_CONFIG *,PAPACC_U64);
PAPACC_RESULT papacc_configuration_recovery_guard04(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_NORMAL_RESTART_WITNESS *);
PAPACC_RESULT papacc_configuration_recovery_validate04(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_recovery_publish04(PAPACC_CONFIGURATION_COMMIT *);
#endif
#ifdef PAPACC_OFFLINE_D3_WORKER
/* Initial namespace phase only. Same worker/packet, no commit or CURRENT.
 * parent is an existing governed local directory, leaf a new single component.
 * explicit caller is administrative; native enabled-admin token required.
 * Retained leases block all other pending operations until stopped/closed. */
PAPACC_RESULT papacc_configuration_bootstrap_custody_begin(PAPACC_CONFIGURATION_COMMIT *,const char *,const char *,PAPACC_SIZE);
PAPACC_RESULT papacc_configuration_bootstrap_custody_poll(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_CAS_RESULT *);
PAPACC_BOOL papacc_configuration_bootstrap_custody_ready(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_bootstrap_custody_close(PAPACC_CONFIGURATION_COMMIT *);
/* Same worker, relative initial FILE_CREATE under retained custody. Durable
 * success is COMMITTED_PENDING only, never CURRENT. Scope/identity native proof
 * and token state are revalidated by worker before commit. */
PAPACC_BOOL papacc_configuration_bootstrap_authority_valid(PAPACC_CONFIGURATION_COMMIT *);
PAPACC_RESULT papacc_configuration_bootstrap_commit_begin(PAPACC_CONFIGURATION_COMMIT *,const PAPACC_U8 *,PAPACC_SIZE,const char *,PAPACC_SIZE);
PAPACC_RESULT papacc_configuration_bootstrap_commit_poll(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_CAS_RESULT *);
/* Offline update only. No bootstrap/recovery/publication; actual current pin
 * and native identity handle required. Last argument is factual already-reserved
 * composition including root, caller and codec pair; extra scratch is checked
 * before effects. Result packet remains root-owned; no credit is released. */
PAPACC_RESULT papacc_configuration_d3_begin08(PAPACC_CONFIGURATION_COMMIT *,
 const PAPACC_CONFIG_PIN *,const PAPACC_U8 *,PAPACC_SIZE,HANDLE,PAPACC_SIZE);
PAPACC_RESULT papacc_configuration_d3_poll08(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_CAS_RESULT *);
/* Factual native commit result, NOT CURRENT/recovery/authorization. Epochs
 * explicitly absent; caller owns full collection copy, no borrowed pointers. */
typedef struct PAPACC_D3_COMMITTED_RECEIPT {
 PAPACC_U8 root[32],commit_digest[32],whole_digest[32];
 PAPACC_U64 revision,predecessor;
 PAPACC_SIZE bytes;
 unsigned listener_count,epochs_present;
} PAPACC_D3_COMMITTED_RECEIPT;
/* Same owner/offline/no-reentry contract as begin08. already_reserved includes
 * the caller receipt+buffers; separate9408 scratch is checked. Original begin
 * input may be reused only after it returned: worker owns frozen copies. */
PAPACC_RESULT papacc_configuration_d3_committed08(PAPACC_CONFIGURATION_COMMIT *,
 PAPACC_U8 *,PAPACC_SIZE,PAPACC_SIZE *,PAPACC_D3_COMMITTED_RECEIPT *,PAPACC_SIZE);
#endif
#if defined(PAPACC_C8_PRIVATE_STORAGE_PROFILE) && defined(PAPACC_OFFLINE_D3_WORKER) && defined(PAPACC_ED11_WINDOWS_3MIB)
#include "config_root8_v3.h"
#include "server_issuer_windows_validation.h"
typedef struct PAPACC_CONFIG_V3_BORROW {
 const PAPACC_U8 *packet,*snt,*pdg,*issuer_image,*ca;
 PAPACC_SIZE packet_bytes,snt_bytes,pdg_bytes,ca_bytes;
 PAPACC_U64 revision,issuer_revision;
} PAPACC_CONFIG_V3_BORROW;
/* DATA-only capture into a prepared free slot. Existing public codec ports are
 * synchronous/nonreentrant, never authority callbacks. Caller retains immutable
 * disjoint inputs and exclusive workspace until return, serializes owner/Stop.
 * Capture does NOT commit/publish/create a pin or mark issuer/CURRENT valid.
 * Missing native/profile/source validation remains its independent gate. */
PAPACC_RESULT papacc_configuration_v3_capture_data(PAPACC_CONFIGURATION_COMMIT *,
 const PAPACC_U8 *,PAPACC_SIZE,const PAPACC_U8 *,PAPACC_SIZE,
 PAPACC_ISSUER_WINDOWS_WORKSPACE *,PC_ROOT8_COMPONENT,void *);
/* Borrow only under the SAME already-held canonical ticket. Caller must keep
 * that ticket unreleased for the entire use (including children/callbacks).
 * No extra acquisition or release API. Stop denies new borrows, preserves old
 * references; unpin(retained) and finish keep their factual-quiescence rules.
 * Output unchanged on failure. Root/slot/pin must outlive the complete borrow.
 * Raw DER has no CERT_INFO pointers; future decode owns its own accounted arena.
 * Historical pin protects memory, NEVER CURRENT/UTC/status/delegation/trust. */
PAPACC_RESULT papacc_configuration_v3_borrow_data(PAPACC_CONFIGURATION_COMMIT *,
 const PAPACC_CONFIG_PIN *,PAPACC_CONFIG_V3_BORROW *);
#endif
#endif
