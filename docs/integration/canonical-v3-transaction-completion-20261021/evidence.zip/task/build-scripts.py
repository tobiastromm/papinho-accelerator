from pathlib import Path
import subprocess
S=Path(__file__).parent;old=S.parent/'pacc-v3-current-e0-20261021'
for profile in ['Selected','Legacy']:
 for cfg in ['Debug','Release']:
  t=(old/f'build-{profile}-{cfg}.cmd').read_text().replace('v3-current-e0-20261021','v3-transaction-20261021')
  if profile=='Selected':t=t.replace('--target ', '--target papacc_v3_transaction_worker_test ',1)
  (S/f'build-{profile}-{cfg}.cmd').write_text(t)
