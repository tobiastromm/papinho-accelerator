from pathlib import Path
import subprocess,json
R=Path(r'C:\Projetos\PapinhoAccelerator');D=R/'build/v3-transaction-native-20261021';D.mkdir(exist_ok=False);rows=[]
for cfg in ['Debug','Release']:
 for mode in ['success','conflict','unknown','stop']:
  name=cfg+'-'+mode;store=D/(name+'.store');p=subprocess.run([str(R/f'build/v3-current-e0-20261021/Selected/{cfg}/papacc_v3_transaction_worker_test.exe'),mode,str(store)],capture_output=True,text=True,timeout=45)
  (D/(name+'.log')).write_text(p.stdout+p.stderr);rows.append({'case':name,'exit':p.returncode,'output':p.stdout+p.stderr,'authority':'SYNTHETIC_ADMIN_NATIVE_IO_ONLY'});print(name,p.returncode,p.stdout,flush=True)
  if p.returncode:break
 if rows[-1]['exit']:break
(D/'results.json').write_text(json.dumps(rows,indent=2));raise SystemExit(any(x['exit'] for x in rows))
