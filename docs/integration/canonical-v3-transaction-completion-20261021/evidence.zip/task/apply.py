from pathlib import Path
import json,hashlib
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S/'operations.json')=='c995a0e2132fd354ec59b2a73825dd63617d6d92ac5e6d87073d1c069cba6225'
ops=json.loads((S/'operations.json').read_text())
for x in ops:assert (sha(R/x['path']) if (R/x['path']).exists() else None)==x['before'];assert sha(S/'staged'/x['path'])==x['after']
for x in ops:(R/x['path']).write_bytes((S/'staged'/x['path']).read_bytes())
print('6_EXACT_APPROVED_OPERATIONS_APPLIED')
