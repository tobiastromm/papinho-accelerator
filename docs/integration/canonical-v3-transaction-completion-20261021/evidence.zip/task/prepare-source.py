from pathlib import Path
import hashlib,json,difflib,zipfile
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;O=S/'staged';files={}
def edit(f,a,b):
 t=(files.get(f) or (R/f).read_bytes()).decode();assert a in t,f;files[f]=t.replace(a,b,1).encode()
edit('apps/server/server_configuration_pending_win32.h','#include "../../src/config/config_root8_v2.h"\r\n#define PAPACC_CONFIG_TRANSACTION_BYTES PC_ROOT8_V2_MAX','#include "../../src/config/config_root8_v3.h"\r\n#define PAPACC_CONFIG_TRANSACTION_BYTES PC_ROOT8_V3_MAX')
f='apps/server/server_configuration_d3_worker_win32.inc'
addition=r'''
#if defined(PAPACC_ED11_WINDOWS_3MIB)
/* Frozen packet persistence guard, NOT component/authority validation. Only a
 * future reviewed canonical producer may authorize production entry. Existing
 * begin08 stays v1-only; no new public begin or CURRENT producer is installed.
 * The test entry below is compile-isolated, synthetic and cannot grant trust. */
static int pending_v3_image_guard(const unsigned char *b,DWORD n)
{
 unsigned N,B,K,D,q,off,s,u,v;unsigned char hash[32];
 if(n<PC_ROOT8_V3_MIN||n>PC_ROOT8_V3_MAX||memcmp(b,"PACROOT8",8)||
    b[8]!=3U||b[9]||b[10]!=0U||b[11]!=2U||d3_u32(b+12)!=n||d3_u32(b+16)!=3U)return 0;
 N=(unsigned)b[20]|((unsigned)b[21]<<8);K=(unsigned)b[252]|((unsigned)b[253]<<8);
 D=(unsigned)b[268]|((unsigned)b[269]<<8);
 if(!N||N>4U||!K||K>N||D>K||d3_u32(b+44)<672U)return 0;
 B=(d3_u32(b+44)-160U)/512U;
 if(!B||B>4U||d3_u32(b+44)!=160U+512U*B)return 0;
 off=512U+1536U*N;s=96U+768U*K;u=off+s;v=96U+384U*D;q=u+v+160U+512U*B+16384U;
 if(q+544U!=n||d3_u32(b+32)!=512U||d3_u32(b+36)!=1536U*N||
 d3_u32(b+244)!=off||d3_u32(b+248)!=s||d3_u32(b+260)!=u||d3_u32(b+264)!=v||
 d3_u32(b+40)!=u+v||d3_u32(b+48)!=u+v+160U+512U*B||d3_u32(b+52)!=16384U||
 d3_u32(b+56)!=q||d3_u32(b+60)!=512U||d3_u32(b+64)!=q+512U||d3_u32(b+68)!=32U)return 0;
 return store03_hash(b,n-32U,hash)&&!memcmp(hash,b+n-32U,32);
}
static int pending_v3_packet_valid(const PAPACC_CONFIG_PENDING *p)
{
 const unsigned char *a=p->previous,*b=p->next,*cp;unsigned aq,bq,as,bs,ap,bp,K,D;unsigned char hash[32];
 if(!pending_v3_image_guard(a,p->previous_bytes)||!pending_v3_image_guard(b,p->next_bytes))return 0;
 aq=d3_u32(a+56);bq=d3_u32(b+56);cp=a+aq;
 if(memcmp(cp,"PACR8CP3",8)||cp[8]!=3U||cp[9]||cp[10]!=0U||cp[11]!=2U||
 !store03_hash(cp,480U,hash)||memcmp(hash,cp+480U,32)||
 !store03_hash(a,aq,hash)||memcmp(hash,cp+88U,32)||
 memcmp(cp+16,a+72,32)||d3_u64(cp+48)!=d3_u64(a+104)||d3_u64(cp+56)!=d3_u64(a+112)||
 !d3_u64(cp+64)||!d3_u64(cp+72)||d3_u64(cp+80)!=d3_u64(a+120)||
 !store03_zero(b+bq,512U)||memcmp(a+72,b+72,32)||
 d3_u64(a+104)==(PAPACC_U64)-1||d3_u64(b+104)!=d3_u64(a+104)+1U||
 d3_u64(b+112)!=d3_u64(a+104)||d3_u64(b+136)!=d3_u64(a+104)||
 d3_u64(b+144)!=d3_u64(cp+64)||d3_u64(b+152)!=d3_u64(cp+72)||
 d3_u64(b+160)!=d3_u64(cp+80)||b[240]!=3U||b[241]||
 memcmp(b+176,cp+88,32)||memcmp(b+208,a+p->previous_bytes-32U,32))return 0;
 /* Bounded first native slice: preserve the ENTIRE carrier and unchanged
  * SNT/PDG rows. It cannot authorize a change of approval/history or issuer. */
 as=d3_u32(a+244);bs=d3_u32(b+244);ap=d3_u32(a+260);bp=d3_u32(b+260);
 K=(unsigned)a[252]|((unsigned)a[253]<<8);D=(unsigned)a[268]|((unsigned)a[269]<<8);
 if(K!=((unsigned)b[252]|((unsigned)b[253]<<8))||D!=((unsigned)b[268]|((unsigned)b[269]<<8))||
 memcmp(a+as+64U,b+bs+64U,768U*K)||memcmp(a+ap+64U,b+bp+64U,384U*D)||
 d3_u64(a+120)!=d3_u64(b+120)||memcmp(a+d3_u32(a+48),b+d3_u32(b+48),16384U))return 0;
 return 1;
}
#endif
'''
files[f]=(R/f).read_bytes()+addition.replace('\n','\r\n').encode()
f='apps/server/server_configuration_pending_win32.inc'
edit(f,'    &&p->packet_format!=8U','    &&p->packet_format!=8U\r\n#if defined(PAPACC_ED11_WINDOWS_3MIB)\r\n    &&p->packet_format!=11U\r\n#endif')
edit(f,' else if(!pending_d3_packet_valid(p))return 0;',' else if(p->packet_format==8U){if(!pending_d3_packet_valid(p))return 0;}\r\n#if defined(PAPACC_ED11_WINDOWS_3MIB)\r\n else if(!pending_v3_packet_valid(p))return 0;\r\n#endif')
edit(f,'\r\n if(p->packet_format==8U){',' if(p->packet_format==8U\r\n#if defined(PAPACC_ED11_WINDOWS_3MIB)\r\n    ||p->packet_format==11U\r\n#endif\r\n   ){')
# A test-only entry invokes the real worker, never a second transaction implementation.
addition=r'''
#if defined(PAPACC_OFFLINE_D3_WORKER) && defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_ISSUER_STORAGE_COMPONENT_TEST)
/* No declaration in production headers; no public/native authority producer.
 * Test owns synthetic immutable packet already copied into SAME owner. */
PAPACC_RESULT papacc_v3_worker_fixture_start(PAPACC_CONFIGURATION_COMMIT *o,HANDLE identity)
{
 PAPACC_CONFIG_PENDING *p;BY_HANDLE_FILE_INFORMATION f;
 if(!owner(o)||o->published||o->prepared||o->committed_pending||o->stopped||o->unresolved||o->authority_lost)return PAPACC_RESULT_INVALID_STATE;
 p=&o->pending_commit;
 if(p->active||p->thread||!pending_v3_packet_valid(p)||identity==INVALID_HANDLE_VALUE||
 !GetFileInformationByHandle(identity,&f)||(f.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT))return PAPACC_RESULT_INVALID_STATE;
 p->packet_format=11U;p->file=INVALID_HANDLE_VALUE;p->expected_volume=f.dwVolumeSerialNumber;
 p->expected_index_high=f.nFileIndexHigh;p->expected_index_low=f.nFileIndexLow;
 memcpy(p->path,o->path,sizeof(p->path));p->result=PAPACC_COMMIT_PENDING;p->active=1;
 p->thread=CreateThread(NULL,PAPACC_PENDING_STACK_BYTES,pending_worker,p,STACK_SIZE_PARAM_IS_A_RESERVATION,NULL);
 if(!p->thread){p->active=0;p->native_error=GetLastError();p->result=PAPACC_COMMIT_FAILED;return PAPACC_RESULT_INTERNAL_ERROR;}
 return PAPACC_RESULT_OK;
}
PAPACC_RESULT papacc_v3_worker_fixture_poll(PAPACC_CONFIGURATION_COMMIT *o,PAPACC_ISSUER_CAS_RESULT *out)
{if(!owner(o)||o->pending_commit.packet_format!=11U)return PAPACC_RESULT_INVALID_STATE;return pending_poll06(o,out);}
#endif
'''
files[f]+=addition.replace('\n','\r\n').encode()
f='tests/kind8_dispatch_win32_test.c';edit(f,'reserved=2220463U+','reserved=2220463U+3U*(PC_ROOT8_V3_MAX-PC_ROOT8_V2_MAX)+')
test=r'''/* Synthetic full v3 administrative context, REAL same-worker native TxF CAS.
 * No root CURRENT/authority, no keys/certificates generated or signature. */
#define _WIN32_WINNT 0x0600
#include "config_root8_v3_test.c"
extern PAPACC_RESULT papacc_v3_worker_fixture_start(PAPACC_CONFIGURATION_COMMIT *,HANDLE);
extern PAPACC_RESULT papacc_v3_worker_fixture_poll(PAPACC_CONFIGURATION_COMMIT *,PAPACC_ISSUER_CAS_RESULT *);
static PAPACC_U8 observed_v3[PC_ROOT8_V3_MAX];
int main(int argc,char **argv)
{
 PAPACC_CONFIG_PENDING *p=&owner.pending_commit;HANDLE file,identity;DWORD count,start;
 PAPACC_ISSUER_CAS_RESULT outcome=PAPACC_COMMIT_IDLE;PAPACC_SIZE bn;unsigned q;int stop,unknown,conflict;
 CHECK(argc==3);stop=!strcmp(argv[1],"stop");unknown=!strcmp(argv[1],"unknown");conflict=!strcmp(argv[1],"conflict");
 CHECK(papacc_configuration_commit_init03(&owner,argv[2])==0);
 CHECK(setup3(4,4,4));CHECK(cp3());bn=z3;memcpy(base3,e3,bn);CHECK(next3(3,bn));
 CHECK(pc_root8_v3_base_link(e3,z3,base3,bn,hash,&owner,component3,NULL)==PC_ROOT8_OK);
 CHECK(sizeof(p->next)==PC_ROOT8_V3_MAX&&sizeof(owner.committed)==PC_ROOT8_V3_MAX);
 memcpy(owner.committed,base3,bn);owner.committed_bytes=(DWORD)bn;
 memcpy(p->previous,base3,bn);p->previous_bytes=(DWORD)bn;memcpy(p->next,e3,z3);p->next_bytes=(DWORD)z3;
 file=CreateFileA(argv[2],GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);CHECK(file!=INVALID_HANDLE_VALUE);
 CHECK(WriteFile(file,base3,(DWORD)bn,&count,NULL)&&count==bn&&FlushFileBuffers(file));CHECK(CloseHandle(file));
 identity=CreateFileA(argv[2],0,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);CHECK(identity!=INVALID_HANDLE_VALUE);
 q=r32(p->previous+56);p->previous[q+64]^=1;CHECK(papacc_v3_worker_fixture_start(&owner,identity)!=0&&!p->thread);p->previous[q+64]^=1;
 p->next[112]^=1;CHECK(papacc_v3_worker_fixture_start(&owner,identity)!=0&&!p->thread);p->next[112]^=1;
 p->next[z3-1]^=1;CHECK(papacc_v3_worker_fixture_start(&owner,identity)!=0&&!p->thread);p->next[z3-1]^=1;
 owner.published=1;CHECK(papacc_v3_worker_fixture_start(&owner,identity)!=0);owner.published=0;
 if(conflict){file=CreateFileA(argv[2],GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);CHECK(file!=INVALID_HANDLE_VALUE);CHECK(SetFilePointer(file,(LONG)(bn-1U),NULL,FILE_BEGIN)!=INVALID_SET_FILE_POINTER);CHECK(WriteFile(file,"X",1,&count,NULL)&&count==1&&FlushFileBuffers(file));CHECK(CloseHandle(file));}
 if(stop){p->test_entered=CreateEventA(NULL,TRUE,FALSE,NULL);p->test_release=CreateEventA(NULL,TRUE,FALSE,NULL);CHECK(p->test_entered&&p->test_release);}
 p->test_unknown=unknown;
 CHECK(papacc_v3_worker_fixture_start(&owner,identity)==0);CHECK(CloseHandle(identity));
 if(stop){CHECK(WaitForSingleObject(p->test_entered,10000)==WAIT_OBJECT_0);start=GetTickCount();CHECK(papacc_configuration_stop(&owner)==0);CHECK(GetTickCount()-start<1000);CHECK(papacc_configuration_finish(&owner)!=0);CHECK(SetEvent(p->test_release));}
 start=GetTickCount();do{CHECK(papacc_v3_worker_fixture_poll(&owner,&outcome)==0);if(outcome==PAPACC_COMMIT_PENDING)Sleep(1);}while(outcome==PAPACC_COMMIT_PENDING&&GetTickCount()-start<10000);
 CHECK(outcome==(stop?PAPACC_COMMIT_FAILED:unknown?PAPACC_CAS_UNKNOWN:conflict?PAPACC_CAS_CONFLICT:PAPACC_CAS_SUCCESS));
 CHECK(!memcmp(owner.committed,base3,bn)&&!memcmp(p->previous,base3,bn));
 CHECK(!memcmp(p->next,e3,z3)&&!owner.published);
 CHECK(!memcmp(p->previous+r32(base3+48),p->next+r32(e3+48),16384));
 CHECK(papacc_configuration_publish(&owner)!=0);
 if(!unknown){file=CreateFileA(argv[2],GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);CHECK(file!=INVALID_HANDLE_VALUE);CHECK(ReadFile(file,observed_v3,sizeof(observed_v3),&count,NULL));CHECK(CloseHandle(file));
 if(!stop&&!conflict){CHECK(count==z3&&!memcmp(observed_v3,e3,z3));}else if(stop){CHECK(count==bn&&!memcmp(observed_v3,base3,bn));}}
 if(stop){CHECK(CloseHandle(p->test_entered));CHECK(CloseHandle(p->test_release));}
 CHECK(papacc_configuration_stop(&owner)==0);if(!stop)CHECK(papacc_configuration_finish(&owner)!=0);
 printf("PASS V3_NATIVE_SAME_WORKER mode=%s outcome=%d bytes=%Iu old_bytes=%Iu owner=%Iu pending=%Iu SYNTHETIC_ADMIN_NO_CURRENT_NO_TRUST_RETAINED\n",argv[1],outcome,z3,bn,sizeof(owner),sizeof(*p));return 0;
}
'''
files['tests/v3_transaction_worker_win32_test.c']=test.replace('\n','\r\n').encode()
f='CMakeLists.txt';addition=r'''
if(PAPACC_ENABLE_OFFLINE_D3_WORKER AND PAPACC_ENABLE_WINDOWS_3MIB_MANAGED_PROFILE)
 add_executable(papacc_v3_transaction_worker_test tests/v3_transaction_worker_win32_test.c apps/server/server_configuration_commit_win32.c apps/server/server_config_root8_data_win32.c)
 target_compile_definitions(papacc_v3_transaction_worker_test PRIVATE PAPACC_OFFLINE_D3_WORKER=1 PAPACC_ISSUER_STORAGE_COMPONENT_TEST=1)
 target_include_directories(papacc_v3_transaction_worker_test PRIVATE ${PAPACC_GRAPH_INCLUDE_DIRS} src/config src/issuer apps/server)
 target_link_libraries(papacc_v3_transaction_worker_test PRIVATE papacc_config_root8 papacc_server_config papacc_issuer papacc_root8_signer_data bcrypt ktmw32 crypt32 advapi32)
 target_compile_options(papacc_v3_transaction_worker_test PRIVATE /W4 /WX)
endif()
''';files[f]=(R/f).read_bytes()+addition.replace('\n','\r\n').encode()
ops=[];patch=[]
with zipfile.ZipFile(S/'preimages.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f,data in files.items():
  before=(R/f).read_bytes() if (R/f).exists() else b'';p=O/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  ops.append({'path':f,'before':hashlib.sha256(before).hexdigest() if (R/f).exists() else None,'after':hashlib.sha256(data).hexdigest()})
  if (R/f).exists():z.writestr(f,before)
  patch.extend(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(S/'source.patch').write_text(''.join(patch),encoding='utf8');(S/'operations.json').write_text(json.dumps(ops,indent=2),encoding='utf8')
print('EXACT_SOURCE',len(ops),hashlib.sha256((S/'operations.json').read_bytes()).hexdigest())


