from pathlib import Path
import json,hashlib
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;p=R/'CMakeLists.txt';before=p.read_bytes();after=before.replace(b'target_compile_definitions(papacc_v3_transaction_worker_test PRIVATE PAPACC_OFFLINE_D3_WORKER=1 PAPACC_ISSUER_STORAGE_COMPONENT_TEST=1)',b'target_compile_definitions(papacc_v3_transaction_worker_test PRIVATE PAPACC_V3_BACKING_FIXTURE=1 PAPACC_OFFLINE_D3_WORKER=1 PAPACC_ISSUER_STORAGE_COMPONENT_TEST=1)');assert before!=after
(S/'repair-before.txt').write_bytes(before);(S/'repair-after.txt').write_bytes(after)
x={'path':'CMakeLists.txt','before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()};(S/'repair.json').write_text(json.dumps(x));print(x)
