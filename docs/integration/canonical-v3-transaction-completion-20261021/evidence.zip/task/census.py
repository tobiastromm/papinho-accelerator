from pathlib import Path
import subprocess,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;rows={}
for profile in ['Selected','Legacy']:
 for cfg in ['Debug','Release']:
  p=R/f'build/v3-current-e0-20261021/{profile}/{cfg}/papacc_phase6_memory_census_test.exe'
  r=subprocess.run([str(p)],capture_output=True,text=True);assert r.returncode==0
  (S/f'census-{profile}-{cfg}.txt').write_text(r.stdout);rows[profile+'-'+cfg]=r.stdout
(S/'compiled-census.json').write_text(json.dumps(rows,indent=2));print('FOUR_COMPILED_CENSUSES_CAPTURED')
