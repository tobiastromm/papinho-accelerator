from pathlib import Path
import json,hashlib,re,subprocess,zipfile
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ops=json.loads((S/'operations.json').read_text());repair=json.loads((S/'repair.json').read_text());expected={x['path']:x['after'] for x in ops};expected[repair['path']]=repair['after']
baseline=json.loads((S/'baseline.json').read_text());pres={}
for name,v in baseline.items():
 root=Path(v['root']);changes=[]
 assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==v['HEAD']
 for f,h in v['hashes'].items():
  if sha(root/f)!=h:
   assert name=='Accelerator' and f in expected and sha(root/f)==expected[f],(name,f)
   changes.append(f)
 pres[name]={'baseline_files':len(v['hashes']),'HEAD':v['HEAD'],'branch':v['branch'],'approved_changes':changes,'unexpected_changes':[],'WIP_preserved':True}
for f,h in expected.items():assert sha(R/f)==h,f
builds=[]
for profile in ['Selected','Legacy']:
 for cfg in ['Debug','Release']:
  log=f'{profile}-{cfg}-'+('clean.log' if profile=='Selected' else 'final.log');t=(S/log).read_text(errors='replace');count=20 if profile=='Selected' else 16
  assert f'0 tests failed out of {count}' in t,log;assert not re.search(r'\bwarning\s+[A-Z]+\d+\s*:',t,re.I),log
  builds.append({'profile':profile,'configuration':cfg,'suites':count,'warnings':0,'log':log})
v3=json.loads((R/'build/v3-transaction-native-20261021/results.json').read_text());hist=json.loads((R/'build/v3-transaction-historical-20261021/native-results.json').read_text());assert len(v3)==8 and len(hist)==16 and all(x['exit']==0 for x in v3+hist)
validation={'builds':builds,'offline_suites':72,'native_v3':v3,'native_historical':hist,'native_total':24,'scope':'NATIVE_IO_WITH_SYNTHETIC_ADMIN_CONTEXT_NOT_FACTUAL_CURRENT','baseline':pres,'initial_attempts':['duplicate fixture main fixed by approved target macro','disk full: initial fresh build tree generated this task removed only after verifying canonical absolute target; logs preserved','incremental Selected layout mismatch: three tests failed; clean rebuild passed without functional changes'],'network':'NOT_RUN','VC6_NT4_box_ISA':'NOT_QUALIFIED'}
(S/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
census={'Windows_explicit_limit':3145728,'Legacy_default_limit':2097152,'Selected_fixed_before':1943680,'Selected_fixed_after':1948576,'Legacy_fixed_before_after':1790872,'delta_fixed':4896,'three_images_each':30592,'old_three_images_each':28960,'commit_owner_product':247032,'root_product':324088,'pending_product':62104,'test_macro_extra_24_not_product':True,'v3_backings_three_slots_unchanged':116616,'existing_worker_stack_reservation':65536,'existing_checkpoint_scratch_reservation':8192,'native_hash_local_digest':32,'full_transitive_stack':'UNKNOWN_NOT_ZERO','BCrypt_provider_CRT_kernel':'UNKNOWN_NOT_ZERO','new_worker_threads_beyond_existing_mechanism':0,'new_permanent_allocations_beyond_three_existing_images':0,'individual_quotas_changed':False,'prior_known_conservative_plus_delta':2225359,'named_dispatch_scenario_plus_delta':2299479,'capture_plus_dispatch_plus_delta':2371143,'full_package_conservative_plus_delta':3747521,'full_package_excess_over_3MiB':601793,'these_scenarios_are_measured_peaks_or_reserved_credit':False,'diagnostic_test_observed_buffer':30592,'diagnostic_process_full_peak':'NOT_QUALIFIED_INHERITED_FIXTURE_ARRAYS_NOT_OPERATIONAL_SOURCE','coexistence':'OLD_COMMITTED_PREVIOUS_NEXT_ALL_RESERVED; no reuse discount; G7 snapshots and pins remain; pending/UNKNOWN handles and credits retained','activation':'DENY_UNTIL_COMPLETE_LIFETIME_BOUND_AND_RESERVATION','ED11_TOTAL_STATUS':'PARTIAL'}
D=Path('docs/integration/canonical-v3-transaction-completion-20261021');O=S/'docs-staged';files={}
def put(n,t):files[str(D/n)]=t.encode('utf8')
put('closeout.md','''# Transação v3 — componente nativo concluído, integração administrativa parcial

CURRENT_TASK_COMPLETED=NO.

O mesmo worker agora discrimina persistência v3→v3 em packet privado11, com capacidade máxima30.592 em suas três imagens existentes. Guards verificam limites, integridade integral, CP3/base/R/A/P/I, predecessor e preservação exata do carrier/SNT/PDG. O CAS nativo compara TODOS os bytes anteriores e identidade do arquivo, usando a transação existente. COMMITTED não publica slot/CURRENT: previous e committed antigos permanecem intactos, o resultado bloqueia autoridade anterior e conserva dados até integração factual.

A entrada de teste é compilada somente no executável diagnóstico, sem declaração em header produtivo e sem BEGIN administrativo novo. Os oito casos nativos usam história e assinatura MODEL, sem autoridade positiva, CA/chave/certificado novo ou CURRENT real. O caminho normal v1 continua separado. Base v2 e alterações de issuer/delegação NÃO foram habilitadas por este slice.

**Bloqueio restante de implementação:** não há produtor canônico que prepare candidato v3 completo e valide kind8 com fontes factuais sob lifetime antes de publicar. O dispatch kind8 atual exige pin de backing já protegido; não é permitido fabricar pin de candidato ou CURRENT para contornar essa diferença. Também faltam base CURRENT/predecessor completo/história de aprovação factuais e sua integração à transação. A implementação dependente foi interrompida nesse gate; não foi classificada como simples falta de ambiente.

Quatro builds finais Debug/Release Selected/Legacy sem warnings;72 suítes offline e24 casos nativos locais passaram (8 v3,16 históricos). Rebuild limpo Selected necessário após mudança de layout. Logs das falhas iniciais de main duplicado, disco cheio e incremental com objetos antigos foram preservados. A única correção de fonte de build foi o define de fixture aprovado; nenhum predicado foi relaxado.

ED11 fixo Selected1.948.576 (+4.896); Legacy1.790.872 inalterado. Janela total operacional não qualificada; provider/kernel/stack transitivo UNKNOWN. Cenário conservador completo3.747.521 excede3MiB por601.793; não é pico medido nem reserva e a ativação permanece DENY.

[Prova e gate](transaction-proof-and-remaining-gate.md) · [Testes](validation.json) · [ED11](ed11-census.json) · [Hashes](final-manifest.json) · [Evidências/preimagens](evidence.zip)

```ini
V3_WORKER_TRANSACTION=NATIVE_PERSISTENCE_SLICE_IMPLEMENTED_NO_CANONICAL_PRODUCER
FULL_PREDECESSOR=FULL_BYTES_CAS_PRESERVED_FACTUAL_AUTHORITY_UNQUALIFIED
CAS_HANDLING=SUCCESS_CONFLICT_UNKNOWN_STOP_DISTINCT_NO_FALLBACK
SNAPSHOT_PIN_LIFETIME=EXISTING_G7_DATA_PRESERVED_CANDIDATE_PROTECTION_GATE_OPEN
CURRENT_PUBLICATION=DENY
BUILDS=4_FINAL_PASS
WARNINGS=0_FINAL_BUILDS
OFFLINE_TESTS=72_PASS
NATIVE_TESTS=24_PASS_SYNTHETIC_ADMIN_CONTEXT
NETWORK_TESTS=NOT_RUN
E0_E8_FACTUAL_SOURCE=DENY
M1_TRUST=DENY
PAPACC_INSTALL=DENY
AUTOMATIC_ENROLLMENT=DENY
SIGNATURE_AUTHORITY=DENY
AUTHORITATIVE_RECOVERY=DENY
CLIENT_ADMISSION=DISABLED
SITE_TLS_ADMISSION=DENY
ED11_ADMISSION=DENY
ED11_TOTAL_STATUS=PARTIAL
PST_CHANGED=NO
BROWSER_CHANGED=NO
PACC_WIRE_CHANGED=NO
PRODUCTION_PIN=0.6.4
WIP_PRESERVED=YES
FIRST_UNRESOLVED_DIVERGENCE=CANONICAL_PREPUBLICATION_V3_PRODUCER_AND_FACTUAL_FULL_PREDECESSOR_LIFETIME_NOT_IMPLEMENTED
NEXT=AUTHORIZED_BOOTSTRAP_AND_V3_CURRENT_QUALIFICATION
```
''')
put('transaction-proof-and-remaining-gate.md','''# Persistência v3 no mesmo worker

## Limites da implementação

As decisões accepted PACROOT8/v3/F1–F5/G0–G7, D2/D3/D4, root/C8, E0–E8 e Model E permanecem intactas. O novo packet_format11 é um discriminador privado do packet do worker, não bytes wire/persistidos. Sua entrada produtiva não foi criada. O teste liga o mesmo código de commit/pending_worker em target isolado como os testes históricos; não introduz segundo worker no processo do produto.

A capacidade das três imagens committed/previous/next do owner existente aumenta de28.960 para30.592 apenas no perfil Windows3MiB explícito. O default/Legacy não muda. A imagem anterior não é sobreposta: worker recebe previous e next por valor; committed e snapshots ficam no owner. O worker não recebe root, pin, Session, callback de autoridade ou ponteiro caller.

Os guards do novo packet verificam magic/versão3, limites e offsets calculados da coleção/SNT/PDG/LST/carrier/checkpoint, SHA256 da imagem inteira, hash CP3 e conteúdo-base, R/predecessor/base/A/P/I e C/W referindo à mesma imagem. Nova CP3 deve estar AUSENTE (512zero): persistência não inventa publicação/epochs. O primeiro slice exige rows SNT/PDG e carrier16384 inteiros idênticos; nenhuma revogação/high-water/reserva/história é removida. Esses checks são integridade/correlação de packet previamente validado, NÃO substituem o codec completo, kind8, policy/status ou fontes factuais.

Begin08/v1 continua usando os guards históricos sem issuer. Packet11 somente é iniciado pelo helper sob PAPACC_ISSUER_STORAGE_COMPONENT_TEST, Windows3MiB/offline, recusando até o bit published diagnóstico. Sem novo símbolo público em header produtivo, CLI ou fallback. O helper não é autoridade: serve exclusivamente à qualificação nativa de IO de fixture, não bootstrap/CURRENT/predecessor administrativo.

## Transação e lifetime

Mesma CreateTransaction/CreateFileTransacted, OPEN_EXISTING e identidade nativa volume/fileindex; comparação inteira em chunks512 com previous imutável; escrita completa, SetEndOfFile, FlushFileBuffers, commit e closes do worker existente. A comparação nativa detecta conflito até no último byte. Não se usa digest no lugar de CAS integral.

Após sucesso factual, poll não sobrescreve committed nem publica pending; marca committed_pending/authority_lost. CONFLICT/UNKNOWN bloqueiam autoridade anterior. UNKNOWN conserva handles/transaction e unresolved; não é rollback. Stop pede parada sem espera, e rollback só é considerado factual pelo resultado nativo do worker. Enquanto thread não sinalizada e close confirmado não há liberação das imagens. Finish nega em pending/retained/unknown e nos resultados que perderam autoridade. G7 mantém suas regras de slot/serial/ticket/borrow; nenhuma segunda tabela de pins foi criada.

O prefixo anterior completo continua em previous e committed durante a operação e após sucesso até resolução governada; isso protege BYTES, não prova aprovação de história nem CURRENT. O novo caminho não emite receipt público de autoridade, checkpoint publicado, lease E0 ou fonte de confiança.

## Provas e limitações

O builder existente valida a relação v3 completa com callback MODEL antes do helper; reutiliza certificado público sintético histórico, sem nova fixture rejeitada ou assinatura privada. Native success/conflict/UNKNOWN/Stop são resultados reais TxF nas imagens máximas30.592. O sucesso compara o arquivo inteiro gravado; Stop/rollback confirmado compara o arquivo anterior inteiro. Todos conservam previous/committed/carrier e não publicam. CP3 corrompido, digest alterado, predecessor divergente e published indevido são rejeitados antes da thread. Esses negativos de corrupção não equivalem a provar status administrativo ou novo certificado nativo positivo.

As72 suítes adicionais cobrem codecs v2/v3, PDG revogado representável como DATA, divergências, kind8 nativo negativo, CURRENT ausente, pins, G7/Stop/retenção, limites e formatos históricos. Os16 casos nativos históricos exercitam ROOT06/high-water/história/snapshots, v1/CAS/Stop. Nenhum resultado é prova de CURRENT real.

## Gate exato antes de completar transação canônica

1. Definir no owner EXISTENTE o caminho de preparação do candidato ainda não publicado, com CA/source/policy/issuer factuais e lifetime; chamar o validador público kind8 sem fingir que candidato possui CURRENT pin. O dispatch atual serve consumo de backing protegido, não faz essa preparação. Se o contrato precisar extensão, propor somente essa fronteira antes de código.
2. Exigir CURRENT v2/v3 factual, pin/revisão/native identity e predecessor integral com CP/história de aprovação. Captura DATA/digest/pending.previous isolados não autorizam isso. O owner já informou indisponibilidade de instalação factual; não criar uma para suprir o teste.
3. Integrar prepare/validate e freeze dos inputs ao mesmo packet/worker, antes de abrir a entrada produtiva, incluindo base v2 e transições permitidas. Mudança de issuer/SNT/PDG depende de proveniência administrativa, não de relaxar memcmp. Preservar os registros anteriores.
4. Reconciliar reserva/retidos/stack/criptografia/coexistência e custos transitivos. Valores numéricos nos testes são guard lower-bound, não ledger factual ou crédito automaticamente disponível. Cenários acima do limite impedem ativação dependente.
5. Só depois de fonte/entrada/autorizações e ambiente próprios qualificar commit canônico, publicação separadamente autorizada e E0. Enquanto isso preflight termina NOT_SUPPORTED e trust_unavailable permanece SOURCE_ABSENT; M1/KDF continuam negados.

Este handoff delimita implementação ainda ausente; não aceita novo contrato, não autoriza executar cerimônia ou publicar CURRENT. [Campanha integrada existente](../canonical-bootstrap-v3-qualification-20261021/campaign.md) segue aplicável, com a capacidade/persistência restrita aqui atualizada.
''')
put('validation.json',json.dumps(validation,indent=2)+'\n');put('ed11-census.json',json.dumps(census,indent=2)+'\n')
put('approval-record.md','''# Revisão oficial e preimagens

Seis operações de fonte autorizadas: operations SHA256 c995a0e2132fd354ec59b2a73825dd63617d6d92ac5e6d87073d1c069cba6225, aplicação oficial chunk5a807f. Preimagens/patch/afterimages e baseline no evidence.zip.

Correção posterior somente CMake: PAPACC_V3_BACKING_FIXTURE=1 no target novo. Repair SHA pre4762b9019201c99c8dcdf673179fd0c9120a34baf73ba0bf10f332ff1e529638 e post3ec0b61ee04c1b1f4f6b52f5b510e2297c73316e5d19aa0f2ed4ce8c8024df09; aplicação oficial chunk664ec9. Primeira tentativa f43ab4 não aplicou nada: repair.json não havia sido gravado por disco cheio; não houve negativa do revisor nem bypass.

A recuperação de espaço removeu somente build/v3-transaction-20261021, árvore gerada nesta tentativa, após conferir seu caminho absoluto canônico. Logs originais TEMP preservados. Árvores anteriores foram reutilizadas com mesma toolchain/flags; Selected finalmente recompilado limpo após falha incremental de layout. Não se usou /PDB:NONE ou redução de warnings para mascarar disco cheio.

Documentação/capability submetida por manifesto exato separado antes de escrever. Estes registros de execução não são atestação externa assinada.
''')
# Preserve logs/config/results and exact source history without fixture stores.
with zipfile.ZipFile(S/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in S.iterdir():
  if p.is_file() and p.name!='evidence.zip':z.write(p,'task/'+p.name)
 for root in [R/'build/v3-transaction-native-20261021',R/'build/v3-transaction-historical-20261021']:
  for p in root.iterdir():
   if p.suffix in ['.json','.log']:z.write(p,str(p.relative_to(R)))
 for prof in ['Selected','Legacy']:
  for cfg in ['Debug','Release']:
   p=R/f'build/v3-current-e0-20261021/{prof}/{cfg}/Testing/Temporary/LastTest.log';z.write(p,str(p.relative_to(R)))
files[str(D/'evidence.zip')]=(S/'evidence.zip').read_bytes()
f='docs/capabilities/client-pairing.md';files[f]=(R/f).read_bytes()+('''\n\n### Persistência v3 no worker — qualificação nativa restrita — 2026-10-21

Mesmo worker aceita internamente packet v3→v3 congelado, com imagens30592 e CAS integral, CP3/predecessor/R/A/P/I e preservação do carrier/SNT/PDG. Entrada apenas no executável diagnóstico por macro, sem begin administrativo positivo: produtor canônico e lifetime pré-publicação de kind8/candidato continuam gates. committed anterior preservado; sucesso não publica CURRENT, UNKNOWN retém e não equivale a rollback. Quatro builds finais sem warnings,72 suítes e24 casos nativos locais passaram (8 v3; todos com contexto administrativo sintético). Fixo Windows explícito1948576 (+4896); Legacy1790872 inalterado. Cenário completo conservador3747521 excede3MiB; total PARTIAL/provider/kernel/stack UNKNOWN, sem ativação. Browser/PST/wire/prod0.6.4 e gates E0/TRUST/CURRENT/assinatura/admissão preservados. [Prova, testes, limites e handoff](../integration/canonical-v3-transaction-completion-20261021/closeout.md).
''').encode('utf8')
m={'task':'PACC-PHASE6-CANONICAL-V3-TRANSACTION-COMPLETION-1','files':[{'path':f,'sha256':sha(R/f)} for f in expected]}
for f,data in files.items():m['files'].append({'path':f,'sha256':hashlib.sha256(data).hexdigest()})
for cfg in ['Debug','Release']:
 f=f'build/v3-current-e0-20261021/Selected/{cfg}/papacc_v3_transaction_worker_test.exe';m['files'].append({'path':f,'sha256':sha(R/f)})
put('final-manifest.json',json.dumps(m,indent=2)+'\n')
O.mkdir(exist_ok=True);dops=[]
for f,data in files.items():
 p=O/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);dops.append({'path':f,'before':sha(R/f) if (R/f).exists() else None,'after':sha(p)})
(S/'docs-operations.json').write_text(json.dumps(dops,indent=2));print('DOCS',len(dops),sha(S/'docs-operations.json'));print('BASELINE',json.dumps(pres));print('FOUR_FINAL_BUILDS_72_SUITES_24_NATIVE_PASS')
