#include <windows.h>
#include <stdio.h>
typedef struct ACT { BYTE sid[SECURITY_MAX_SID_SIZE]; TOKEN_STATISTICS statistics; BYTE candidate_hash[32],predecessor_hash[32]; HANDLE retained_token,retained_process_token; DWORD sid_bytes,native_error; unsigned state,status; } ACT;
int main(void){printf("ACT=%u ALIGN_PTR=%u TOKEN_STATISTICS=%u SID_MAX=%u\n",(unsigned)sizeof(ACT),(unsigned)sizeof(void *),(unsigned)sizeof(TOKEN_STATISTICS),(unsigned)SECURITY_MAX_SID_SIZE);return 0;}

