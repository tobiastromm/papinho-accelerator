from pathlib import Path
import json,hashlib,subprocess
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'docs/integration/canonical-v3-transaction-completion-20261021/final-manifest.json').read_text())
for x in m['files']:assert sha(R/x['path'])==x['sha256'],x['path']
print('PRIOR_MANIFEST_15_ENTRIES_VERIFIED')
old=S.parent/'pacc-v3-transaction-20261021'
for profile in ['Selected','Legacy']:
 for cfg in ['Debug','Release']:
  t=(old/f'reuse-{profile}-{cfg}.cmd').read_text();(S/f'build-{profile}-{cfg}.cmd').write_text(t)
