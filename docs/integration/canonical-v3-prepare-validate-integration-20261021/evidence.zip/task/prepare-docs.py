from pathlib import Path
import json,hashlib,subprocess,re,zipfile
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((S/'baseline.json').read_text())
for name,v in b.items():
 root=Path(v['root']);assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==v['HEAD']
 for f,h in v['hashes'].items():assert sha(root/f)==h,(name,f)
rows=[]
for profile in ['Selected','Legacy']:
 for cfg in ['Debug','Release']:
  p=S/f'{profile}-{cfg}.log';t=p.read_text(errors='replace');n=20 if profile=='Selected' else 16
  assert f'0 tests failed out of {n}' in t;assert not re.search(r'\bwarning\s+[A-Z]+\d+\s*:',t,re.I)
  rows.append({'profile':profile,'configuration':cfg,'suites_passed':n,'warnings':0,'build':'VERIFIED_UP_TO_DATE_UNCHANGED_SOURCE','log':p.name})
v3=json.loads((R/'build/v3-prepare-validate-native-20261021/results.json').read_text());hist=json.loads((R/'build/v3-prepare-validate-historical-20261021/native-results.json').read_text());assert len(v3)==8 and len(hist)==16 and all(x['exit']==0 for x in v3+hist)
source=['apps/server/server_launcher_owner_win32.c','apps/server/server_launcher_owner_win32.h','apps/server/server_configuration_participants_win32.inc','apps/server/server_configuration_root_transaction_win32.inc','apps/server/server_configuration_v3_backings_win32.inc','apps/server/server_configuration_pending_win32.inc','apps/server/server_config_root8_data_win32.c']
proof={'task':'PACC-PHASE6-CANONICAL-V3-PREPARE-VALIDATE-INTEGRATION-1','code_sha256':{f:sha(R/f) for f in source},'builds':rows,'offline_suites':72,'native_v3':v3,'native_historical':hist,'positive_canonical_prepare_validate_v3':'NOT_IMPLEMENTED_NOT_QUALIFIED','new_functional_patch':False,'canonical_CURRENT':'NOT_AVAILABLE_PER_OWNER_NO_SYNTHETIC_SUBSTITUTE','network':'NOT_RUN','WIP':{n:{'HEAD':v['HEAD'],'branch':v['branch'],'files_unchanged':len(v['hashes'])} for n,v in b.items()},'LAB_access':'NONE','prior_manifest_entries_verified':15}
(S/'verification.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
D=Path('docs/integration/canonical-v3-prepare-validate-integration-20261021');O=S/'staged';files={}
def put(n,t):files[str(D/n)]=t.encode('utf8')
put('producer-gap-and-minimum-integration.md','''# Produtor canônico: fronteira exata ainda não integrada

Esta auditoria não altera contrato accepted, API, layout ou fonte funcional. Não cria outro produtor e não registra nova decisão. Complementa a [prova do worker](../canonical-v3-transaction-completion-20261021/transaction-proof-and-remaining-gate.md), sem repetir seus testes como prova positiva de preparação.

## Chamadas existentes e incompatibilidade factual

| Ponto real | Precondição / ownership atual | Consequência para v3 update |
|---|---|---|
| server_launcher_owner_win32.c: preparation_owned | singleton root, thread owner, launcher ACTIVE | Só esse owner pode preparar; componente diagnóstico não pode substituir o produtor |
| configuration_prepare_source | t.state EMPTY; commit não inicializado, exceto root_recovery_candidate_matches; nenhum runtime/listener ativo. Copia o.config para t.model e inicia source | Não oferece entrada de atualização sobre CURRENT publicado; retorno NOT_SUPPORTED mesmo após source_prepare OK não significa VALIDATED v3 |
| root_policy_model_valid / policy_prepare_model | t.model.config é cercado por igualdade com o.config; commit inicializado só aceito como candidato de recuperação | t.model participa da geração atual; reescrevê-lo com candidato não constitui preparação isolada |
| participant_candidate / prepare_listener/capabilities/C2 | Mesmo t, source/runtime/provider e modelo; commit inicializado exige recovery matching | Falta geração candidata de update com fontes próprias protegidas; remover condição de recovery enfraqueceria o fence |
| transaction_prepare_store | Somente primeiro commit dormente: expected deve ser zero, commit não inicializado, dormant_applied | Não é dispatcher v3. expected-base/CURRENT update não é um modo atualmente implementado nessa entrada |
| configuration_current/current_pin | Commit e publicação normativos, modelo/C2/epochs/projeção e pin factuais | Geração publicada deve permanecer imutável enquanto prepara o sucessor; bitmap, digest ou imagem fixture não satisfazem o contrato |
| v3_capture_data / pinned_signer | Captura exige free prepared slot; kind8 de consumo exige backing já protegido por pin e ranges exatos | Não fornece autorização de preparação. Fabricar pin do candidato ainda não publicado não é solução de lifetime |
| packet11 | Guard/persistência no mesmo worker, entrada somente por macro de teste | Não existe chamada produtiva de prepare/validate/commit v3; sucesso TxF diagnóstico não cria esse caminho |

Não foi encontrada fonte CURRENT factual nova. A ausência já declarada pelo owner continua respeitada, sem repetir solicitação de store nem criar um para teste. O bloqueio do produtor é IMPLEMENTAÇÃO/LIFETIME, distinto do bloqueio AMBIENTAL de CURRENT e token administrativo.

## Plano mínimo de implementação no MESMO produtor

1. Modelar a atualização como fase da preparação existente, separada de bootstrap/restore. Fixar antes de qualquer mutação a identidade/revisão do CURRENT v2/v3, seu pin, imagem completa e checkpoint/história de fontes. Não reusar t.model/source da geração vigente como scratch candidato. O estado/pin predecessor deve permanecer alcançável pelo mesmo owner durante PREPARE→RESULT e resultados retidos.
2. Usar slots/backings G7 já existentes para candidato e manter o predecessor no slot pinado. Escolher slot livre por critérios canônicos, sem substituir slot com readers/retained e sem segunda tabela de pins. A coleção completa é preservada: target singular pode recusar N>1, jamais truncá-lo.
3. Resolver referências do candidato por fontes administrativas reais, mantendo borrows/CA/issuer/policy e sua revisão. Definir claramente validação síncrona PREPUBLICAÇÃO: ela pode consumir referências já protegidas do owner, sem fingir CURRENT/pin publicado para o candidato. O dispatch atual de consumo permanece protegido; um adapter candidato só pode ser implementado após comprovar proveniência/lifetime dessas entradas. Sem fonte, resultado DENY, não callback MODEL convertido em RESOLVED.
4. Comparar predecessor inteiro (imagem/checkpoint/R/A/P/I/C/W/native identity/histórico), não apenas LST1/digest. Validar SNT/PDG, purpose/status/revogação e issuer sem inferir aprovação de bytes. Atualizações de aprovação não podem ser obtidas pela remoção dos memcmp de preservação do packet11.
5. Somente após sucesso de todas as validações e reserva factual congelar previous/next no packet existente. O prepare/validate não inicia thread nem publica; commit separado revalida CURRENT/pin/Stop/native identity imediatamente antes do efeito. Reutilizar pending_worker/TxF e suas dispositions; NÃO mover source/policy/pins ao worker nem criar outro produtor.
6. Definir término do mesmo grafo: abort antes de efeito libera apenas candidato após quiescência; commit/UNKNOWN/Stop pendente mantêm ambas as gerações e créditos; liberação de predecessor depende de fechamento factual e todos os borrows/Sessions. As rotinas históricas transaction_abort/close atualmente operam sobre t inteiro; não chamá-las como se já fossem abort de candidato de update.
7. Reconciliar layout compilado e pico transitivo dessa extensão ANTES de aplicar campos/hunks. As autoridades accepted limitam o resultado; se os fatos demandarem representação/autoridade adicional não coberta, propor somente essa extensão, nunca preencher campos por inferência.

Esses itens são trabalho funcional pendente, não claims de APIs implementadas nem decisão normativa nova. Nenhum hunk que apenas removesse guards ou encaminhasse buffers foi submetido como integração segura. A ligação dependente permanece interrompida por falta de predecessor factual e prova do lifetime desse grafo de update. O plano não presume que falta de ambiente dispense os itens1–7.

## Provas necessárias e resultado desta execução

Prepare v3 positivo e validate v3 positivo: NÃO IMPLEMENTADOS/QUALIFICADOS. Para uma implementação posterior, exigir testes de geração atual intacta antes/durante preparo, candidato sem pin fictício, referências divergentes/ausentes, predecessor divergente, issuer/PDG/CP3 corrompidos, status/revogação, abort antes de efeito, CAS conflict/UNKNOWN, Stop com worker e borrows, quiescência e slots retidos. Positivos de fixture ficam identificados como MODEL, sem autoridade operacional.

Nesta tarefa, quatro targets/configurações de build existentes foram verificados atualizados sem warnings e72 suítes existentes passaram.24 casos nativos locais foram reexecutados sobre stores fixture exclusivos:8 v3 e16 históricos. Eles preservam regressões de persistência, negativos CURRENT/pins, formatos e G7; não comprovam um produtor ainda ausente. O manifesto anterior de15 entradas e todo baseline dos dois projetos foram verificados.

## ED11

Sem alteração funcional ou armazenamento adicional nesta auditoria: Selected fixo1.948.576 /3.145.728 explícito; Legacy1.790.872 /2.097.152. As três imagens30592, backings116616 e reservas de stack existentes continuam contabilizadas no [censo anterior](../canonical-v3-transaction-completion-20261021/ed11-census.json).

O novo grafo de preparação NÃO recebe reserva por este plano. Seu custo deverá incluir candidate model/source/material, predecessor/pin, CA/issuer/status, crypto/hash/encode/decode, caller arenas, stack, handles, instrumentação, concorrência e resultados retidos. Reuso requer lifetime demonstrado; não contar twice imagens já no owner nem omitir coexistência possível. O cenário conservador completo3.747.521 supera3MiB em601.793; não é pico operacional medido. Provider/kernel/stack transitivo UNKNOWN; ativação dependente e ED11 total permanecem DENY/PARTIAL. Nenhuma quota ou limite foi modificado.
''')
put('closeout.md','''# Prepare/validate v3 — integração não concluída

CURRENT_TASK_COMPLETED=NO.

O produtor canônico foi localizado em configuration_prepare_source/policy/participants/transaction_prepare_store. Ele implementa preparação inicial dormente e reconstrução de recuperação; não possui transição de update v3 que preserve o grafo CURRENT enquanto prepara o candidato. Seu estado/model/source também é usado pelas verificações CURRENT. Nenhum guard foi relaxado e nenhum wrapper negativo redundante foi adicionado.

A integração dependente permanece negada: falta predecessor CURRENT factual completo e protegido, além da implementação/prova de lifetime da geração candidata. Isso é uma combinação de lacuna funcional e fonte factual indisponível, não apenas problema de sandbox. [Mapa de código e plano mínimo no mesmo owner](producer-gap-and-minimum-integration.md).

Nenhuma fonte funcional foi modificada. Quatro verificações Debug/Release Selected/Legacy (targets atualizados, sem nova compilação necessária) sem warnings;72 suítes existentes e24 casos nativos locais passaram. Não há teste positivo de prepare/validate canônico v3. Contextos administrativos dos casos nativos são sintéticos; os efeitos filesystem/CAS são reais e não conferem CURRENT.

[Resultados](validation.json) · [Evidências/baseline](evidence.zip) · [Hashes](final-manifest.json).

```ini
V3_PREPARE_VALIDATE=NOT_INTEGRATED_LIFETIME_AND_FACTUAL_PREDECESSOR_GATE
CANONICAL_PRODUCER=LOCATED_DORMANT_PREPARATION_UPDATE_PHASE_MISSING
FULL_PREDECESSOR=PENDING_FACTUAL_SOURCE_AND_PROTECTION
V3_WORKER_TRANSACTION=EXISTING_NATIVE_PERSISTENCE_SLICE_PRESERVED
CURRENT_PUBLICATION=DENY
BUILDS=4_UP_TO_DATE_VERIFICATIONS_NO_NEW_COMPILATION
WARNINGS=0
OFFLINE_TESTS=72_EXISTING_SUITES_PASS_NO_POSITIVE_V3_PREPARE_PROOF
NATIVE_TESTS=24_PASS_SYNTHETIC_ADMIN_CONTEXT
NETWORK_TESTS=NOT_RUN
E0_E8_FACTUAL_SOURCE=DENY
M1_TRUST=DENY
PAPACC_INSTALL=DENY
AUTOMATIC_ENROLLMENT=DENY
SIGNATURE_AUTHORITY=DENY
AUTHORITATIVE_RECOVERY=DENY
CLIENT_ADMISSION=DISABLED
SITE_TLS_ADMISSION=DENY
ED11_ADMISSION=DENY
ED11_TOTAL_STATUS=PARTIAL
PST_CHANGED=NO
BROWSER_CHANGED=NO
PACC_WIRE_CHANGED=NO
PRODUCTION_PIN=0.6.4
WIP_PRESERVED=YES
FIRST_UNRESOLVED_DIVERGENCE=CANONICAL_UPDATE_PREPARATION_COHORT_LIFETIME_AND_FACTUAL_PREDECESSOR_MISSING
NEXT=AUTHORIZED_V3_BOOTSTRAP_CURRENT_AND_E0_QUALIFICATION
```

O rótulo NEXT não autoriza bootstrap em versão3: G0 mantém v3 update-only de base v2/v3; cerimônia inicial continua v1 sob autorização própria.
''')
put('validation.json',json.dumps(proof,indent=2)+'\n')
with zipfile.ZipFile(S/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in S.iterdir():
  if p.is_file() and p.name!='evidence.zip':z.write(p,'task/'+p.name)
 for folder in ['v3-prepare-validate-native-20261021','v3-prepare-validate-historical-20261021']:
  for p in (R/'build'/folder).iterdir():
   if p.suffix in ['.log','.json']:z.write(p,str(p.relative_to(R)))
files[str(D/'evidence.zip')]=(S/'evidence.zip').read_bytes()
m={'task':proof['task'],'files':[{'path':f,'sha256':hashlib.sha256(data).hexdigest()} for f,data in files.items()],'unchanged_code_sha256':proof['code_sha256']};put('final-manifest.json',json.dumps(m,indent=2)+'\n')
O.mkdir(exist_ok=True);ops=[]
for f,data in files.items():
 p=O/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);assert not (R/f).exists();ops.append({'path':f,'before':None,'after':sha(p)})
(S/'operations.json').write_text(json.dumps(ops,indent=2));print('DOCUMENTATION_ONLY',len(ops),sha(S/'operations.json'));print('ALL_BASELINE_FILES_UNCHANGED',len(b['Accelerator']['hashes']),len(b['Browser']['hashes']))
