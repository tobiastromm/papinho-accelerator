import pathlib,json,hashlib,re,subprocess
root=pathlib.Path(r'C:\Projetos\PapinhoAccelerator'); stage=pathlib.Path(__file__).parent
old=root/'docs/integration/delegation-v3-native-current-binding-20261021/final-manifest.json'
m=json.loads(old.read_text(encoding='utf8')); bad=[]
for f,v in m.items():
 p=root/f
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=v['sha256']:bad.append(f)
(stage/'prior-manifest-verification.json').write_text(json.dumps({'manifest_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'entries':len(m),'mismatches':bad},indent=2),encoding='utf8')
if bad:raise SystemExit('STOP prior manifest mismatch '+str(bad))
results=[]
for profile in ['Selected','Legacy']:
 for mode in ['Debug','Release']:
  b=root/'build/kind8-20261021'/profile/mode
  for line in (b/'CTestTestfile.cmake').read_text().splitlines():
   match=re.match(r'add_test\(([^ ]+) (.*)\)$',line)
   if not match or not re.match(r'papacc\.(config_root8\.|root8\.kind8|ed11\.|phase6\.memory_census)',match[1]):continue
   cmd=re.findall(r'"([^"]*)"',match[2]); exe=pathlib.Path(cmd[0]); key=str(exe.relative_to(root)).replace('\\','/')
   exe_hash=hashlib.sha256(exe.read_bytes()).hexdigest()
   r=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=60)
   name=profile+'-'+mode+'-'+match[1]+'.log';(stage/name).write_text(r.stdout+r.stderr,encoding='utf8')
   results.append({'profile':profile,'mode':mode,'test':match[1],'exit_code':r.returncode,'executable':key,'sha256':exe_hash,'prior_executable_pin':key in m,'log':name})
   if r.returncode:raise SystemExit('STOP test failed '+name)
(stage/'regressions.json').write_text(json.dumps(results,indent=2),encoding='utf8')
print(json.dumps({'prior_manifest_entries':len(m),'prior_manifest_mismatches':bad,'independent_reexecutions':len(results),'passed':all(r['exit_code']==0 for r in results),'new_builds':False}))
