from pathlib import Path
S=Path(__file__).parent;old=S.parent/'pacc-v3-transaction-20261021'
for p in ['Selected','Legacy']:
 for c in ['Debug','Release']:
  t=(old/f'reuse-{p}-{c}.cmd').read_text()
  if p=='Selected':t=t.replace('--target papacc_v3_transaction_worker_test','--clean-first --target papacc_v3_update_cohort_test papacc_v3_transaction_worker_test',1).replace('papacc.v3.current_negative"','papacc.v3.current_negative|papacc.v3.update_cohort"')
  (S/f'build-{p}-{c}.cmd').write_text(t)
