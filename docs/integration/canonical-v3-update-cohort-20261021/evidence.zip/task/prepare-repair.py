from pathlib import Path
import hashlib,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;ops=[]
f='apps/server/server_configuration_commit_win32.h';before=(R/f).read_bytes();t=before.decode();t=t.replace('#if defined(PAPACC_C8_PRIVATE_STORAGE_PROFILE) && defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_OFFLINE_D3_WORKER)','#if defined(PAPACC_C8_PRIVATE_STORAGE_PROFILE) && defined(PAPACC_ED11_WINDOWS_3MIB)');t=t.replace('#ifdef PAPACC_OFFLINE_D3_WORKER\r\n    PAPACC_V3_UPDATE_COHORT v3_update;\r\n#endif','    PAPACC_V3_UPDATE_COHORT v3_update;');after=t.encode();assert before!=after
p=S/'repair-staged'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after);(S/'repair-header-preimage.h').write_bytes(before);ops.append({'path':f,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()})
f='tests/v3_update_cohort_win32_test.c';before=(R/f).read_bytes();after=before.replace(b'stale=pin;stale.ticket++;',b'stale=pin;stale.ticket=owner.next_ticket+1U;');assert before!=after
p=S/'repair-staged'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after);(S/'repair-test-preimage.c').write_bytes(before);ops.append({'path':f,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()})
(S/'repair-operations.json').write_text(json.dumps(ops,indent=2));print(hashlib.sha256((S/'repair-operations.json').read_bytes()).hexdigest())
