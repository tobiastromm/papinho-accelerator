from pathlib import Path
import hashlib,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S/'scope-operations.json')=='0acfadb29e37974edf41b172b1f2fa82d2d57158d1651b263bad73206248d697'
ops=json.loads((S/'scope-operations.json').read_text())
for x in ops:assert sha(R/x['path'])==x['before'];assert sha(S/'scope-staged'/x['path'])==x['after']
for x in ops:(R/x['path']).write_bytes((S/'scope-staged'/x['path']).read_bytes())
print('EXACT_DORMANT_CURRENT_SESSION_AND_STOP_SCOPE_GUARDS_APPLIED')
