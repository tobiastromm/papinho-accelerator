from pathlib import Path
import subprocess,re,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;frames={};dump=r'C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\dumpbin.exe'
for cfg in ['Debug','Release']:
 for target,src,names in [('papacc_configuration_commit','server_configuration_commit_win32.c',['papacc_configuration_v3_update_hold_data','papacc_configuration_v3_update_abort_data']),('papacc_server_run_win32','server_launcher_owner_win32.c',['papacc_server_launcher_configuration_v3_update_hold','papacc_server_launcher_configuration_v3_update_validate','papacc_server_launcher_configuration_v3_update_abort'])]:
  obj=R/f'build/v3-current-e0-20261021/Selected/{cfg}/CMakeFiles/{target}.dir/apps/server/{src}.obj'
  t=subprocess.check_output([dump,'/disasm',str(obj)],text=True,errors='replace');(S/f'disasm-{cfg}-{target}.txt').write_text(t)
  for name in names:
   at=t.find(name+':');section=t[at:at+3500] if at>=0 else '';m=re.search(r'sub\s+rsp,([0-9A-Fa-f]+)h',section)
   frames[cfg+'-'+name]=int(m.group(1),16) if m else 'NOT_EXTRACTED_OR_INLINED'
 for profile in ['Selected','Legacy']:
  exe=R/f'build/v3-current-e0-20261021/{profile}/{cfg}/papacc_phase6_memory_census_test.exe';p=subprocess.run([str(exe)],capture_output=True,text=True);assert p.returncode==0;(S/f'census-{profile}-{cfg}.txt').write_text(p.stdout)
(S/'direct-frames.json').write_text(json.dumps({'direct_sub_rsp_only':frames,'includes_pushes_nested_calls_provider_CRT':False,'transitive_stack':'UNKNOWN_NOT_ZERO'},indent=2));print(json.dumps(frames))
