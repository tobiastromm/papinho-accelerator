from pathlib import Path
import hashlib,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S/'repair-operations.json')=='dea7bc6a5e3f61ff9daeb580428ae49f0331290fc51226b8a6ea665a968cec22'
ops=json.loads((S/'repair-operations.json').read_text())
for x in ops:assert sha(R/x['path'])==x['before'];assert sha(S/'repair-staged'/x['path'])==x['after']
for x in ops:(R/x['path']).write_bytes((S/'repair-staged'/x['path']).read_bytes())
print('TWO_EXACT_LAYOUT_AND_STALE_TICKET_REPAIRS_APPLIED')
