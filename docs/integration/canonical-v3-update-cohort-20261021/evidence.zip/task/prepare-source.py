from pathlib import Path
import hashlib,json,difflib,zipfile
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;F={}
def edit(f,a,b):
 t=F.get(f,(R/f).read_bytes()).decode();assert a in t,f;F[f]=t.replace(a,b,1).encode()
schema=(S/'cohort-schema.txt').read_text().replace('\n','\r\n')
h='apps/server/server_configuration_commit_win32.h'
edit(h,'typedef struct PAPACC_CONFIGURATION_COMMIT {','#if defined(PAPACC_C8_PRIVATE_STORAGE_PROFILE) && defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_OFFLINE_D3_WORKER)\r\n/* Same owner, one unresolved UPDATE; real predecessor ticket, no candidate pin. */\r\n#define PAPACC_V3_UPDATE_EMPTY 0U\r\n#define PAPACC_V3_UPDATE_HELD 1U\r\n#define PAPACC_V3_UPDATE_RETAINED 2U\r\n'+schema+'#endif\r\ntypedef struct PAPACC_CONFIGURATION_COMMIT {')
edit(h,'    PAPACC_CONFIG_V3_BACKING v3_backings[PAPACC_CONFIG_SLOTS];','    PAPACC_CONFIG_V3_BACKING v3_backings[PAPACC_CONFIG_SLOTS];\r\n#ifdef PAPACC_OFFLINE_D3_WORKER\r\n    PAPACC_V3_UPDATE_COHORT v3_update;\r\n#endif')
edit(h,'} PAPACC_CONFIGURATION_COMMIT;','} PAPACC_CONFIGURATION_COMMIT;\r\n#if defined(PAPACC_C8_PRIVATE_STORAGE_PROFILE) && defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_OFFLINE_D3_WORKER)\r\n#define PAPACC_V3_UPDATE_BUSY(o) ((o)->v3_update.phase!=PAPACC_V3_UPDATE_EMPTY)\r\n#else\r\n#define PAPACC_V3_UPDATE_BUSY(o) 0\r\n#endif')
anchor='PAPACC_RESULT papacc_configuration_v3_checkpoint_match_data(\r\n PAPACC_CONFIGURATION_COMMIT *,const PAPACC_CONFIG_PIN *);'
edit(h,anchor,anchor+'''\r
/* Synchronous lifetime/staging ONLY. On OK, consumes the existing pin by move
 * (caller pin cleared), owns a free G7 slot and copies complete input by value.
 * No validation/RESOLVED/commit/CURRENT. Root must separately prove authority.
 * Input remains caller-owned through return; reserved is lower-bound accounting,
 * never a grant. Abort releases only after factual cohort quiescence; retained
 * phase keeps the same pin/slot reachable. No candidate borrow is exported. */
PAPACC_RESULT papacc_configuration_v3_update_hold_data(PAPACC_CONFIGURATION_COMMIT *,
 PAPACC_CONFIG_PIN *,const PAPACC_U8 *,PAPACC_SIZE,PAPACC_SIZE,PAPACC_U64);
PAPACC_RESULT papacc_configuration_v3_update_abort_data(PAPACC_CONFIGURATION_COMMIT *);
'''.replace('\n','\r\n'))
f='apps/server/server_configuration_commit_win32.c'
edit(f,'#include "server_configuration_v3_backings_win32.inc"','#include "server_configuration_v3_backings_win32.inc"\r\n#include "server_configuration_v3_update_cohort_win32.inc"')
# Mutating legacy entries may not consume the cohort or its unresolved candidate.
text=F[f].decode()
for name in ['papacc_configuration_prepare','papacc_configuration_commit','papacc_configuration_publish','papacc_configuration_abort','papacc_configuration_finish']:
 start=text.index('PAPACC_RESULT '+name+'(');brace=text.index('{',start);end=text.index('\n}',brace)+2;chunk=text[start:end]
 marker='    EnterCriticalSection(&o->lock);';assert marker in chunk,name
 chunk=chunk.replace(marker,'    if(PAPACC_V3_UPDATE_BUSY(o))return PAPACC_RESULT_INVALID_STATE;\r\n'+marker,1);text=text[:start]+chunk+text[end:]
F[f]=text.encode()
f='apps/server/server_configuration_v3_backings_win32.inc';edit(f,'return o->prepared&&!o->committed_pending','return !PAPACC_V3_UPDATE_BUSY(o)&&o->prepared&&!o->committed_pending')
cohort=r'''/* Same canonical owner and existing G7 slots. Unresolved lifetime only. */
PAPACC_RESULT papacc_configuration_v3_update_hold_data(PAPACC_CONFIGURATION_COMMIT *o,
 PAPACC_CONFIG_PIN *pin,const PAPACC_U8 *image,PAPACC_SIZE n,PAPACC_SIZE reserved,PAPACC_U64 invocation)
{
 PAPACC_CONFIG_V3_BORROW base;PAPACC_CONFIG_V3_BACKING *candidate;PAPACC_CONFIG_SLOT *slot;
 PAPACC_V3_UPDATE_COHORT *u;PAPACC_U8 digest[32];PAPACC_SIZE q,off;unsigned index;
 if(!owner(o)||!pin||!v3b_range(image,n)||n<PC_ROOT8_V3_MIN||n>PC_ROOT8_V3_MAX||!invocation||
 issuer06_overlap(o,sizeof(*o),image,n)||issuer06_overlap(o,sizeof(*o),pin,sizeof(*pin))||
 issuer06_overlap(pin,sizeof(*pin),image,n))return PAPACC_RESULT_INVALID_ARGUMENT;
 if(reserved<sizeof(*o)||reserved>PAPACC_ED11_PROCESS_LIMIT||
 n+sizeof(base)+sizeof(digest)>PAPACC_ED11_PROCESS_LIMIT-reserved)return PAPACC_RESULT_LIMIT_EXCEEDED;
 if(PAPACC_V3_UPDATE_BUSY(o)||o->prepared||o->committed_pending||o->stopped||o->unresolved||
 o->authority_lost||o->recovery_selected||o->recovery_guard||pending_blocks(o)||
 o->pending_commit.thread||o->pending_commit.transaction||o->pending_commit.close_error||
 o->pending_commit.result!=PAPACC_COMMIT_IDLE||o->pending_commit.previous_bytes||o->pending_commit.next_bytes)
 return PAPACC_RESULT_INVALID_STATE;
 if(papacc_configuration_v3_checkpoint_match_data(o,pin)!=PAPACC_RESULT_OK||
 papacc_configuration_v3_borrow_data(o,pin,&base)!=PAPACC_RESULT_OK)return PAPACC_RESULT_INVALID_STATE;
 /* Bounds and correlation only, not the component/source validators. */
 q=v3b32(image+56);off=v3b32(image+48);
 if(memcmp(image,"PACROOT8",8)||image[8]!=3U||image[9]||v3b32(image+12)!=n||q!=n-544U||
 off>q||q-off!=16384U||memcmp(image+72,base.packet+72,32)||
 base.revision==(PAPACC_U64)-1||v3b64(image+104)!=base.revision+1U||
 v3b64(image+112)!=base.revision||v3b64(image+136)!=base.revision||
 v3b64(image+144)!=o->slots[pin->index].context_epoch||v3b64(image+152)!=o->slots[pin->index].operational_epoch||
 v3b64(image+160)!=base.issuer_revision||v3b64(image+120)!=base.issuer_revision||
 memcmp(image+176,base.packet+v3b32(base.packet+56)+88,32)||
 memcmp(image+208,base.packet+base.packet_bytes-32U,32)||
 memcmp(image+off,base.packet+v3b32(base.packet+48),16384U)||
 !store03_zero(image+q,512U)||!papacc_configuration_issuer_hash06(o,image,n-32U,digest)||memcmp(digest,image+n-32U,32))
 return PAPACC_RESULT_INVALID_ARGUMENT;
 /* Hash/native work has returned; no pending child borrows the inputs. */
 EnterCriticalSection(&o->lock);u=&o->v3_update;
 if(PAPACC_V3_UPDATE_BUSY(o)||o->prepared||o->stopped||o->unresolved||o->authority_lost||
 pending_blocks(o)||pin->index!=o->current||o->next_serial==(PAPACC_U64)-1||
 o->committed_bytes!=base.packet_bytes||memcmp(o->committed,base.packet,base.packet_bytes)){
 LeaveCriticalSection(&o->lock);return PAPACC_RESULT_INVALID_STATE;}
 for(index=0;index<PAPACC_CONFIG_SLOTS;index++)if(index!=o->current&&!o->slots[index].readers&&!o->slots[index].retained)break;
 if(index==PAPACC_CONFIG_SLOTS){LeaveCriticalSection(&o->lock);return PAPACC_RESULT_LIMIT_EXCEEDED;}
 slot=&o->slots[index];candidate=&o->v3_backings[index];
 memset(candidate,0,sizeof(*candidate));memcpy(candidate->packet,image,n);candidate->packet_bytes=n;
 memcpy(candidate->ca,base.ca,base.ca_bytes);candidate->ca_bytes=base.ca_bytes;
 /* serial stays ZERO: unresolved candidate cannot be a G7 exported borrow. */
 memset(&slot->view,0,sizeof(slot->view));memcpy(slot->view.domain,image+72,32);
 slot->view.revision=base.revision+1U;slot->view.predecessor=base.revision;
 slot->context_epoch=0;slot->operational_epoch=0;slot->issuer_revision=0;
 slot->serial=++o->next_serial;o->issuer_snapshot_valid[index]=0;
 u->predecessor_pin=*pin;memset(pin,0,sizeof(*pin));u->candidate_serial=slot->serial;
 u->candidate_index=index;u->prior_pending=o->pending;u->invocation=invocation;u->reserved=reserved;
 memcpy(o->pending_commit.previous,base.packet,base.packet_bytes);o->pending_commit.previous_bytes=(DWORD)base.packet_bytes;
 o->pending=index;o->prepared=1;u->phase=PAPACC_V3_UPDATE_HELD;
 LeaveCriticalSection(&o->lock);return PAPACC_RESULT_OK;
}
PAPACC_RESULT papacc_configuration_v3_update_abort_data(PAPACC_CONFIGURATION_COMMIT *o)
{
 PAPACC_V3_UPDATE_COHORT *u;PAPACC_CONFIG_SLOT *s;PAPACC_RESULT result;
 if(!owner(o)||!PAPACC_V3_UPDATE_BUSY(o))return PAPACC_RESULT_INVALID_STATE;
 EnterCriticalSection(&o->lock);u=&o->v3_update;
 /* This phase starts no child work and exports no candidate borrow. Still
  * prove quiescence/slot identity; absence of a lease or timeout is not proof. */
 if(u->source_ticket||o->pending_commit.active||o->pending_commit.thread||
 o->pending_commit.transaction||o->pending_commit.file!=INVALID_HANDLE_VALUE||
 o->pending_commit.close_error||o->unresolved||o->committed_pending){
 u->phase=PAPACC_V3_UPDATE_RETAINED;LeaveCriticalSection(&o->lock);return PAPACC_RESULT_INVALID_STATE;}
 if(u->candidate_serial){
  if(u->candidate_index>=PAPACC_CONFIG_SLOTS||u->candidate_index==o->current){u->phase=PAPACC_V3_UPDATE_RETAINED;LeaveCriticalSection(&o->lock);return PAPACC_RESULT_INVALID_STATE;}
  s=&o->slots[u->candidate_index];
  if(s->serial!=u->candidate_serial||s->readers||s->retained||o->v3_backings[u->candidate_index].serial){
   u->phase=PAPACC_V3_UPDATE_RETAINED;LeaveCriticalSection(&o->lock);return PAPACC_RESULT_INVALID_STATE;}
 }
 result=papacc_configuration_unpin(o,&u->predecessor_pin,0);
 if(result!=PAPACC_RESULT_OK){u->phase=PAPACC_V3_UPDATE_RETAINED;LeaveCriticalSection(&o->lock);return result;}
 if(u->candidate_serial){
  memset(&o->v3_backings[u->candidate_index],0,sizeof(o->v3_backings[0]));
  memset(&o->slots[u->candidate_index],0,sizeof(o->slots[0]));
  memset(o->pending_commit.previous,0,o->pending_commit.previous_bytes);o->pending_commit.previous_bytes=0;
  o->pending=u->prior_pending;o->prepared=0;
 }
 memset(u,0,sizeof(*u));LeaveCriticalSection(&o->lock);return PAPACC_RESULT_OK;
}
'''
F['apps/server/server_configuration_v3_update_cohort_win32.inc']=cohort.replace('\n','\r\n').encode()
f='apps/server/server_configuration_root_transaction_win32.inc'
root=r'''
#if defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_OFFLINE_D3_WORKER)
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_hold(
 PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *o,const PAPACC_U8 *candidate,PAPACC_SIZE bytes,PAPACC_SIZE reserved)
{
 PAPACC_ROOT_CURRENT_PIN base;PAPACC_CONFIGURATION_COMMIT *c;PAPACC_RESULT result,release;
 const PAPACC_RESOLVED_SERVER_SECURITY_CONFIGURATION *source=NULL;
 if(!preparation_owned(o))return PAPACC_RESULT_INVALID_STATE;c=&o->configuration_commit;
 if(PAPACC_V3_UPDATE_BUSY(c)||papacc_server_console_win32_stop_requested()==PAPACC_TRUE||
 reserved<o->configuration_preparation.combined_reserved||reserved>PAPACC_ED11_PROCESS_LIMIT||
 sizeof(base)>PAPACC_ED11_PROCESS_LIMIT-reserved)return PAPACC_RESULT_INVALID_STATE;
 memset(&base,0,sizeof(base));result=papacc_server_launcher_configuration_current_pin(o,&base);
 if(result!=PAPACC_RESULT_OK)return result;
 if(papacc_server_launcher_configuration_current(o,&base)!=PAPACC_TRUE)result=PAPACC_RESULT_INVALID_STATE;
 else result=papacc_configuration_v3_update_hold_data(c,&base.pin,candidate,bytes,reserved+sizeof(base),o->invocation);
 if(base.pin.ticket){
  release=papacc_configuration_unpin(c,&base.pin,0);
  if(release!=PAPACC_RESULT_OK){
   c->v3_update.predecessor_pin=base.pin;c->v3_update.invocation=o->invocation;
   c->v3_update.phase=PAPACC_V3_UPDATE_RETAINED;return release;
  }
 }
 if(result!=PAPACC_RESULT_OK)return result;
 /* Keep the PUBLISHED source immutable; only its existing borrower ticket is
  * acquired. This does not resolve arbitrary candidate refs or policy. */
 result=papacc_server_security_source_borrow(&o->configuration_preparation.source,&c->v3_update.source_ticket,&source);
 if(result!=PAPACC_RESULT_OK||!source)return result==PAPACC_RESULT_OK?PAPACC_RESULT_INVALID_STATE:result;
 return PAPACC_RESULT_NOT_SUPPORTED; /* HELD, not RESOLVED/VALIDATED or commit */
}
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_validate(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *o)
{
 PAPACC_V3_UPDATE_COHORT *u;PAPACC_ROOT_CURRENT_PIN p;PAPACC_RESULT result;
 if(!preparation_owned(o)||papacc_server_console_win32_stop_requested()==PAPACC_TRUE)return PAPACC_RESULT_INVALID_STATE;
 u=&o->configuration_commit.v3_update;
 if(u->phase!=PAPACC_V3_UPDATE_HELD||u->invocation!=o->invocation||!u->source_ticket||
 papacc_server_security_source_validate(&o->configuration_preparation.source)!=PAPACC_RESULT_OK)return PAPACC_RESULT_INVALID_STATE;
 /* Rebuild a view of the SAME owned canonical ticket, never mint a pin/epoch. */
 memset(&p,0,sizeof(p));p.pin=u->predecessor_pin;p.invocation=o->invocation;
 result=papacc_configuration_pin_read(&o->configuration_commit,&p.pin,&p.view,&p.administrative_epoch,&p.epoch);
 if(result!=PAPACC_RESULT_OK)return result;
 p.issuer_present=PAPACC_TRUE;p.issuer_revision=o->configuration_commit.slots[p.pin.index].issuer_revision;
 if(papacc_server_launcher_configuration_current(o,&p)!=PAPACC_TRUE)return PAPACC_RESULT_INVALID_STATE;
 return PAPACC_RESULT_NOT_SUPPORTED; /* no candidate-source approval producer */
}
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_commit(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *o)
{return papacc_server_launcher_configuration_v3_update_validate(o); /* unresolved never reaches packet11 */}
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_abort(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *o)
{
 PAPACC_V3_UPDATE_COHORT *u;PAPACC_RESULT result;
 /* Retained owner remains reachable for cleanup; Stop does not destroy it. */
 if(o!=&root||GetCurrentThreadId()!=o->owner_thread||!o->configuration_commit.initialized)return PAPACC_RESULT_INVALID_STATE;
 u=&o->configuration_commit.v3_update;
 if(!PAPACC_V3_UPDATE_BUSY(&o->configuration_commit)||u->invocation!=o->invocation)return PAPACC_RESULT_INVALID_STATE;
 if(u->source_ticket){
  result=papacc_server_security_source_unborrow(&o->configuration_preparation.source,u->source_ticket);
  if(result!=PAPACC_RESULT_OK){u->phase=PAPACC_V3_UPDATE_RETAINED;return result;}u->source_ticket=0;
 }
 return papacc_configuration_v3_update_abort_data(&o->configuration_commit);
}
#endif
'''
F[f]=(R/f).read_bytes()+root.replace('\n','\r\n').encode()
f='apps/server/server_launcher_owner_win32.h'
anchor='PAPACC_RESULT papacc_server_launcher_configuration_v3_evidence_preflight(\r\n PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *,const PAPACC_ROOT_CURRENT_PIN *);'
# Locate actual spelling without parameter names.
t=F.get(f,(R/f).read_bytes()).decode();pos=t.find('PAPACC_RESULT papacc_server_launcher_configuration_v3_evidence_preflight(');assert pos>=0;end=t.index(';',pos)+1
api='''
/* UPDATE cohort only. Hold can retain bytes/pin/source while returning
 * NOT_SUPPORTED: inspect configuration_commit.v3_update and use dedicated
 * abort, never historical transaction_abort/close. No validated/commit state
 * is available without factual candidate sources. Stop preserves ownership. */
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_hold(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *,const PAPACC_U8 *,PAPACC_SIZE,PAPACC_SIZE);
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_validate(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *);
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_commit(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *);
PAPACC_RESULT papacc_server_launcher_configuration_v3_update_abort(PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *);
'''.replace('\n','\r\n');F[f]=(t[:end]+api+t[end:]).encode()
f='tests/kind8_dispatch_win32_test.c';edit(f,'reserved=2220463U+3U*(PC_ROOT8_V3_MAX-PC_ROOT8_V2_MAX)+','reserved=2220463U+3U*(PC_ROOT8_V3_MAX-PC_ROOT8_V2_MAX)+sizeof(PAPACC_V3_UPDATE_COHORT)+')
# Stage exactly; test/CMake added in next preparation step before approval.
O=S/'staged';O.mkdir(exist_ok=True)
for f,data in F.items():p=O/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(S/'source-paths.json').write_text(json.dumps(list(F)));print('STAGED_IMPLEMENTATION_FILES',len(F))
