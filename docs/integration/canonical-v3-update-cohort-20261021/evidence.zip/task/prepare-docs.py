from pathlib import Path
import json,hashlib,subprocess,re,zipfile
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sourceops=json.loads((S/'operations.json').read_text())+json.loads((S/'repair-operations.json').read_text())+json.loads((S/'scope-operations.json').read_text());expected={x['path']:x['after'] for x in sourceops};b=json.loads((S/'baseline.json').read_text());pres={}
for name,v in b.items():
 root=Path(v['root']);changed=[];assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==v['HEAD']
 for f,h in v['hashes'].items():
  if sha(root/f)!=h:assert name=='Accelerator' and f in expected and sha(root/f)==expected[f],(name,f);changed.append(f)
 pres[name]={'HEAD':v['HEAD'],'branch':v['branch'],'baseline_files':len(v['hashes']),'approved_changes':changed,'unexpected_changes':[],'WIP_preserved':True}
for f,h in expected.items():assert sha(R/f)==h,f
builds=[]
for profile in ['Selected','Legacy']:
 for cfg in ['Debug','Release']:
  log=f'{profile}-{cfg}-'+('scoped.log' if profile=='Selected' else 'final.log');t=(S/log).read_text(errors='replace');count=21 if profile=='Selected' else 16
  assert f'0 tests failed out of {count}' in t;assert not re.search(r'\bwarning\s+[A-Z]+\d+\s*:',t,re.I),log
  builds.append({'profile':profile,'configuration':cfg,'tests_passed':count,'warnings':0,'log':log})
v3=json.loads((R/'build/v3-update-cohort-native-20261021/results.json').read_text());hist=json.loads((R/'build/v3-update-cohort-historical-20261021/native-results.json').read_text());assert len(v3)==8 and len(hist)==16 and all(x['exit']==0 for x in v3+hist)
validation={'builds':builds,'offline_suites':74,'cohort_checks_each_configuration':108,'native_v3':v3,'native_historical':hist,'native_total':24,'positive_cohort':'MODEL_CURRENT_ONLY_NATIVE_PUBLIC_HASH_AND_CANONICAL_TICKET_CODE','real_canonical_root':'NEGATIVE_CURRENT_ABSENT_NO_MUTATION','native_positive_CURRENT':'NOT_AVAILABLE_NOT_FABRICATED','initial_failures':'3 Selected suites failed: mixed OFFLINE layout guards, test stale-ticket collision; exact approved repair; final clean builds and regressions passed','network':'NOT_RUN','other_targets_NT4_box_ISA':'NOT_QUALIFIED','baseline':pres}
(S/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
frames=json.loads((S/'direct-frames.json').read_text())
census={'Windows_explicit_limit':3145728,'Legacy_limit':2097152,'Selected_fixed_before':1948576,'Selected_fixed_after':1948656,'new_fixed':80,'Legacy_fixed_before_after':1790872,'root_after':324168,'commit_owner_after':247112,'pending_unchanged':62104,'cohort_descriptor':80,'existing_backings_3_slots':116616,'existing_images_3x30592':91776,'new_arrays_heap_workers_pin_tables':0,'source':'borrow published source using existing 8-ticket pool; no source/material copy; not candidate reference approval','input_caller_image_max':30592,'predecessor':'existing committed and pending.previous; existing canonical ticket moved, not new table','candidate':'existing free G7 packet/CA by value, serial0, no exported borrow or pin','owner_worker_stack_reserve_existing':65536,'owner_checkpoint_scratch_reserve_existing':8192,'direct_frames_not_full_stack':frames,'new_core_local_borrow_and_digest':120,'frame_contains_local_root_pin_do_not_charge_twice':True,'known_conservative_plus_descriptor':2225439,'named_dispatch_plus_descriptor':2299559,'capture_and_dispatch_plus_descriptor':2371223,'full_package_conservative_plus_descriptor':3747601,'full_package_excess':601873,'scenarios_measured_peaks_or_credit':False,'known_fixed_margin_not_credit':1197072,'coexistence':'3 slots/images fully priced; never reuse pinned/retained slots; HOLD excludes worker activity and unresolved packet; canonical entry dormant without Session pins','native_provider_kernel_CRT_transitive_stack':'UNKNOWN_NOT_ZERO','operational_ED11_total':'PARTIAL','full_activation_and_dependent_commit':'DENY','quotas_changed':False}
D=Path('docs/integration/canonical-v3-update-cohort-20261021');O=S/'docs-staged';F={}
def put(n,t):F[str(D/n)]=t.encode('utf8')
put('closeout.md','''# Cohort UPDATE v3 — implementação delimitada e qualificação parcial

CURRENT_TASK_COMPLETED=NO.

Implementado um cohort de80 bytes no owner existente, sem segunda root/produtor/pin table. O produtor canônico pode manter a geração anterior protegida enquanto copia bytes candidatos para um slot G7 livre, com serial0, sem pin do candidato. t.model/source publicados não viram scratch. O pin predecessor real é movido para o cohort e a source publicada usa somente seu mecanismo de borrow existente. Staging não significa RESOLVED/VALIDATED.

A entrada é UPDATE dormente, distinta de bootstrap/restore; nega runtime ativo, attachment/listener/Session pins e operações pendentes. O primeiro subconjunto usa predecessor v3 protegido; base v2 permanece não integrada. Sem CURRENT factual, nega sem criar cohort. Validar e commitar permanecem negados: fontes de aprovação/referências do candidato e predecessor factual não foram qualificadas; packet11 não é iniciado pelo cohort não resolvido.

Abort próprio verifica quiescência, identidade/serial de slot e ausência de worker/handles/resultado incerto antes de unborrow/unpin. Stop não limpa nem libera; os mutadores históricos não consomem o candidato. Incerteza mantém ambas as gerações e crédito alcançáveis no mesmo owner.

Gate pré-patch: esquema80 confirmado por probe MSVC/W4/WX antes dos hunks, prova/hash congelados. Censo compilado final Selected1.948.656 (+80), Legacy1.790.872 inalterado. Cenário completo conservador3.747.601 excede3MiB em601.873 e não autoriza ativação. ED11 totalPARTIAL/provider-kernel-stack UNKNOWN; nenhum aumento de quota.

Quatro builds finais sem warnings;74 suítes offline e24 casos nativos locais passaram. Positivo de lifetime é CURRENT MODEL com SHA/CA pública e tickets reais do componente; o singleton real foi exercitado somente em negativos sem CURRENT. Não há qualificação positiva de CURRENT, source/commit do cohort ou E0. Falhas iniciais e reparos exatos preservados.

[Ownership/lifecycle e gate restante](ownership-lifetime-and-gates.md) · [Gate pré-patch](prepatch-lifetime-capacity-proof.json) · [ED11](ed11-census.json) · [Testes](validation.json) · [Hashes](final-manifest.json) · [Evidências](evidence.zip)

```ini
V3_UPDATE_COHORT=IMPLEMENTED_DORMANT_UNRESOLVED_STAGING_V3_BASE_SUBSET
CURRENT_IMMUTABILITY=PASS_MODEL_NATIVE_PIN_CODE_REAL_ROOT_NEGATIVES
CANDIDATE_LIFETIME=OWNED_G7_SLOT_NO_CANDIDATE_PIN_ABORT_AFTER_QUIESCENCE
FULL_PREDECESSOR=COMPLETE_BYTES_AND_PIN_HELD_FACTUAL_ROOT_QUALIFICATION_PENDING
ED11_RECONCILIATION=80_FIXED_BYTES_ADDED_NO_QUOTA_CHANGE_FULL_ACTIVATION_DENY
BUILDS=4_FINAL_PASS
WARNINGS=0_FINAL_BUILDS
OFFLINE_TESTS=74_PASS
NATIVE_TESTS=24_PASS_SYNTHETIC_ADMIN_CONTEXT
NETWORK_TESTS=NOT_RUN
CURRENT_PUBLICATION=DENY
E0_E8_FACTUAL_SOURCE=DENY
M1_TRUST=DENY
PAPACC_INSTALL=DENY
AUTOMATIC_ENROLLMENT=DENY
SIGNATURE_AUTHORITY=DENY
AUTHORITATIVE_RECOVERY=DENY
CLIENT_ADMISSION=DISABLED
SITE_TLS_ADMISSION=DENY
ED11_ADMISSION=DENY
ED11_TOTAL_STATUS=PARTIAL
PST_CHANGED=NO
BROWSER_CHANGED=NO
PACC_WIRE_CHANGED=NO
PRODUCTION_PIN=0.6.4
WIP_PRESERVED=YES
FIRST_UNRESOLVED_DIVERGENCE=FACTUAL_CANDIDATE_REFERENCE_APPROVAL_AND_COMPLETE_CURRENT_SOURCE_UNQUALIFIED_VALIDATE_COMMIT_DENIED
NEXT=AUTHORIZED_V3_UPDATE_PREPARE_VALIDATE_QUALIFICATION
```
''')
put('ownership-lifetime-and-gates.md','''# Prova do cohort no produtor/owner existentes

## Gate pré-patch e compatibilidade

Esquema nativo temporário compilado antes de alterar fontes: sizeof(PAPACC_V3_UPDATE_COHORT)==80, MSVC/W4/WX. SHA da prova pré-patch a27b3a220c6c5150721c6f9e41192162a618435d6eec52592031973d68fc5f70. O descritor mantém predecessor_pin, serial do candidato, source_ticket, invocação, lower-bound reserved, fase, índice e pending anterior. Não contém autoridade booleana, novo epoch, ponteiro externo retido ou storage de credenciais. Não é serializado. Layout comum a todos os consumidores Windows3MiB; funções novas apenas no opt-in offline. Default/Legacy/box/ISA não recebem alteração de orçamento ou layout pelo profile Windows.

D2.2/G0/G7 permitem mesma root/owner com base CURRENT, snapshot/pin e coexistência; a implementação não revoga guards de bootstrap/restore, não aceita baseROOT06/v1 nem inicialização v3. Não altera PACROOT8/PDG1/CP3/SNT1/LST1/BODY ou hash domains. E0–E8, M1 e ownership compartilhado não recebem fontes/leases/fábricas positivas. Não foi aceita decisão normativa nova ou API wire.

## Inventário e ownership

| Objeto | Owner / tamanho | Início e término factual | Coexistência |
|---|---|---|---|
| Descritor80 | configuration_commit dentro da root canônica | Fase EMPTY→HELD; limpo após abort factual | Reservado em todos layouts Windows Selected; sem pool paralelo |
| Predecessor pin | Ticket canônico existente32 dentro dos80 | current_pin real no produtor; hold move e zera o pin local; abort unpin factual | Protege geração antiga e CA/SNT/PDG/carrier G7; não publica candidato |
| Predecessor completo | committed + G7 CURRENT + pending.previous30592, todos já reservados | Copiado inteiro para previous no hold; committed/G7 anterior nunca sobrepostos | Mantém CP3/R/A/P/I/C/W e histórico issuer durante hold/Stop/retido |
| Candidato | Slot G7 livre packet30592/CA8192 já entre3 slots reservados | Cópia por valor; slot serial próprio; backing serial0 até validação futura | Sem pointer caller, sem pin, sem borrow candidato exportado; slots reader/retained excluídos |
| Source antiga | Objeto publicado t.source permanece owner; ticket8 nos80 | borrow existente após hold; unborrow próprio depois de quiescência | Material e configuração não copiados ou usados como scratch; borrower extra protege lifetime, não resolve refs candidatas |
| Input caller | Até30592 bytes | Imutável e exclusivo até retorno; depois reutilizável | Lower-bound do call contabiliza input e locais; não vira crédito factual |
| Frames/hash | Caller/owner; medidos em direct-frames.json no evidence.zip | Somente chamada síncrona, sem filho pendente | Stack transitivo/provider/kernel UNKNOWN; nenhum hash/close é iniciado por Stop |

Hold DATA recusa owner/pin inválidos, limite/reserva insuficiente, store não8, operações pendentes/incertas e comprometimento anterior não disposto. Confere pin atual, backing íntegro, imagem committed inteira, R/predecessor/A/P/I/C/W; candidato exige versão3, bounds, hash completo, checkpoint ausente e carrier inteiro idêntico ao predecessor. São checks de staging/correlação, NÃO validador completo de PDG/SNT, perfil X509, aprovação ou status. Um candidato internamente inválido mas re-selado jamais alcança RESOLVED: validação positiva não existe neste slice.

Seleção de slot, cópia e transferência do ticket ocorrem sob lock após retorno do trabalho hash; rechecagem da tabela canônica confirma ticket/serial/readers. Campo serial0 do backing impede que validação futura confunda bytes staged com snapshot exportável. O slot recebe somente domínio/R/predecessor candidatos; A/P/I e flag issuer válida permanecem ausentes. Não se inventa publicação.

## Integração com o produtor canônico

configuration_v3_update_hold exige singleton/thread canônicos, runtime dormente, ausência de pins de Sessions/listener/attachment, CURRENT factual e reserve compatível com combined_reserved. Adquire pin por current_pin existente e o transfere ao descritor, preservando alcançabilidade até num erro de release. Usa source_borrow existente sem mudar t.model, policy, source material ou estado de publicação. Retorno NOT_SUPPORTED pode significar cohort HELD; o caller deve consultar o descritor no mesmo owner e usar update_abort, não transaction_abort/close histórico. Esse padrão não é acquire E0 nem aquisição assíncrona; não há lease SDK.

configuration_v3_update_validate lê a mesma referência canônica, A/P/I e invocação existentes, revalida CURRENT/source e ticket source. Não emite novo pin/epoch. Termina NOT_SUPPORTED por falta do produtor factual de aprovação/referências candidatas. update_commit também nega e não chama packet11. Sem CURRENT/source reais, os guards anteriores negam sem fabricar estado. A primeira implementação não suporta base v2, fonte alterada, validação positiva ou operação online.

## Dispositions e liberação

| Estado/fato | Ação segura |
|---|---|
| Hold rejeitado antes de move | Pin caller permanece; nenhum slot/cópia ou owner novo |
| HELD não resolvido | Mesmo owner conserva pin, bytes e source_ticket; sem worker/commit/CURRENT |
| Stop | Sinaliza pelos caminhos existentes; nega validação/novos efeitos; não libera recursos |
| Abort antes de efeito | Verificar thread/transaction/file/close/result/slot/serial/readers e source; unborrow source, depois unpin; somente então limpar slot/cópia e restaurar pending anterior |
| Falha de quiescência/release | RETAINED; mesmos recursos alcançáveis, nenhuma liberação por timeout |
| Necessidade de COMMITTED/CONFLICT/UNKNOWN | Cohort não resolvido não inicia efeito. Worker11 existente distingue resultados e retém incerteza. Integração futura deve preservar ambos grafos e revalidar autoridade/reserva imediatamente antes do efeito |

Os mutadores históricos prepare/commit/publish/abort/finish e a captura G7 não podem consumir/sobrescrever o cohort. current/current_pin continuam a reconhecer a geração anterior no modelo enquanto hold não causa efeito; Stop invalida aplicabilidade mas mantém memória protegida. Abort próprio não usa cleanup da preparação publicada. Se houver resultado não-IDLE/UNKNOWN, handles ou commit pendente, abort conserva ambas gerações e source; não supõe rollback/cancelamento.

## Provas e próximos gates

108 checks por configuração no novo teste: ticket obsoleto não emitido, slots ocupados, predecessor/issuer/CP3/PDG corrompidos, reserve insuficiente, pin transferido, CURRENT-modelo e committed inalterados, bytes candidatos isolados do caller, mutadores históricos negados, slot não quiescente retido, abort, Stop, borrow anterior preservado e finish só após unpin. Contexto CURRENT é explicitamente MODEL; SHA/CA pública e operações de ticket/unpin são nativas. Singleton real é somente negativo: sem CURRENT/source/store, hold/validate/commit/abort negam e t.model/source/preparação ficam intactos. Não há prova nativa de autoridade positiva.

Permanecem: fonte CURRENT/predecessor factual e histórico completo; resolução/proveniência/status/revogação de referências candidatas; validação completa kind8 pré-publicação sem pin fictício; base v2 e alterações autorizadas de source/issuer/policy; reservas factuais e integração ao packet11; resultado e eventual publicação separadamente autorizada. O cohort80 resolve ownership/staging, não substitui essas dependências. Não criar store/CURRENT para suprir a ausência já declarada pelo owner.
''')
put('prepatch-lifetime-capacity-proof.json',(S/'prepatch-lifetime-capacity-proof.json').read_text())
put('validation.json',json.dumps(validation,indent=2)+'\n');put('ed11-census.json',json.dumps(census,indent=2)+'\n')
put('approval-record.md','''# Operações exatas e revisão oficial

Fonte9 operações SHA256 2a12088603f09ca2f6a2b106905675f94d49c4c90b20ebf288c50eb89906092a, aplicação oficial020524. Gate pré-patch SHA a27b3a220c6c5150721c6f9e41192162a618435d6eec52592031973d68fc5f70 e probe80 precedem as mudanças.

Reparo2 operações SHA dea7bc6a5e3f61ff9daeb580428ae49f0331290fc51226b8a6ea665a968cec22, aplicação7509f3: layout80 comum a todos consumidores Windows3MiB, funções ainda offline-only; fixture usa ticket não emitido em vez de colidir com spectator válido. Falhas iniciais preservadas; predicados de lifetime não relaxados. Rebuild Selected limpo e21/21 regressões finais por configuração.

Restrição2 hunks SHA 0acfadb29e37974edf41b172b1f2fa82d2d57158d1651b263bad73206248d697, aplicação5eb6ef: store8 e modo dormente sem pins Session/listener/attachment; Stop rechecado antes de source borrow. Zero nova reserva além dos80.

Não houve negativa oficial ou bypass. Preimagens, afterimages, patches/scripts, logs, disassembly e baseline estão no evidence.zip. Identificadores são registros da execução, não assinatura externa. Documentação submetida por manifesto exato separado antes da escrita. Nenhum ADR accepted ou formato foi alterado.
''')
# Evidence without stores or any secret material.
with zipfile.ZipFile(S/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in S.iterdir():
  if p.is_file() and p.name!='evidence.zip':z.write(p,'task/'+p.name)
 for folder in ['v3-update-cohort-native-20261021','v3-update-cohort-historical-20261021']:
  for p in (R/'build'/folder).iterdir():
   if p.suffix in ['.json','.log']:z.write(p,str(p.relative_to(R)))
 for profile in ['Selected','Legacy']:
  for cfg in ['Debug','Release']:
   p=R/f'build/v3-current-e0-20261021/{profile}/{cfg}/Testing/Temporary/LastTest.log';z.write(p,str(p.relative_to(R)))
F[str(D/'evidence.zip')]=(S/'evidence.zip').read_bytes()
f='docs/capabilities/client-pairing.md';F[f]=(R/f).read_bytes()+('''\n\n### Cohort UPDATE v3 — ownership/staging sem autoridade — 2026-10-21

Owner canônico ganhou descritor80 para manter predecessor com pin real e candidato por valor em slot G7 livre/serial0, sem pin candidato ou scratch em t.model/source publicados. Entrada somente UPDATE dormente sem Session pins; validação/commit permanecem DENY sem fontes factuais. Abort próprio conserva recursos em falta de quiescência, Stop ou resultado incerto. Fixo Selected1948656 (+80), Legacy1790872 intacto;74 suítes e24 casos nativos locais passaram em4 builds finais sem warnings. Positivo de lifetime é MODEL com hash/tickets nativos; singleton real apenas negativo sem CURRENT. Cenário completo conservador3747601 excede3MiB e não é reserva/pico; ED11 PARTIAL/provider-kernel-stack UNKNOWN. Base v2, resolução/commit do cohort e CURRENT/E0/TRUST/assinatura/admissão seguem pendentes/negados. [Prova pré-patch, lifecycle, testes, censo e hashes](../integration/canonical-v3-update-cohort-20261021/closeout.md).
''').encode('utf8')
m={'task':'PACC-PHASE6-CANONICAL-V3-UPDATE-COHORT-1','files':[{'path':f,'sha256':sha(R/f)} for f in expected]}
for f,data in F.items():m['files'].append({'path':f,'sha256':hashlib.sha256(data).hexdigest()})
for cfg in ['Debug','Release']:
 f=f'build/v3-current-e0-20261021/Selected/{cfg}/papacc_v3_update_cohort_test.exe';m['files'].append({'path':f,'sha256':sha(R/f)})
put('final-manifest.json',json.dumps(m,indent=2)+'\n')
O.mkdir(exist_ok=True);ops=[]
for f,data in F.items():
 p=O/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);ops.append({'path':f,'before':sha(R/f) if (R/f).exists() else None,'after':sha(p)})
(S/'docs-operations.json').write_text(json.dumps(ops,indent=2));print('EXACT_DOC_OPERATIONS',len(ops),sha(S/'docs-operations.json'));print('BASELINE_VERIFIED',json.dumps(pres))
