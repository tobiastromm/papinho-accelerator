#include "server_c8_private_storage_layout_win32.h"
typedef struct PAPACC_V3_UPDATE_COHORT {
 PAPACC_CONFIG_PIN predecessor_pin;
 PAPACC_U64 candidate_serial,source_ticket,invocation;
 PAPACC_SIZE reserved;
 unsigned phase,candidate_index,prior_pending;
} PAPACC_V3_UPDATE_COHORT;
typedef char cohort_size_is_80[(sizeof(PAPACC_V3_UPDATE_COHORT)==80)?1:-1];
int cohort_size_probe(void){return (int)sizeof(PAPACC_V3_UPDATE_COHORT);}
