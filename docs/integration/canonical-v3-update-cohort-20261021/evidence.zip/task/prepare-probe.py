from pathlib import Path
import subprocess,re,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent
schema='''typedef struct PAPACC_V3_UPDATE_COHORT {
 PAPACC_CONFIG_PIN predecessor_pin;
 PAPACC_U64 candidate_serial,source_ticket,invocation;
 PAPACC_SIZE reserved;
 unsigned phase,candidate_index,prior_pending;
} PAPACC_V3_UPDATE_COHORT;
'''
(S/'cohort-schema.txt').write_text(schema)
(S/'probe.c').write_text('#include "server_c8_private_storage_layout_win32.h"\n'+schema+'typedef char cohort_size_is_80[(sizeof(PAPACC_V3_UPDATE_COHORT)==80)?1:-1];\nint cohort_size_probe(void){return (int)sizeof(PAPACC_V3_UPDATE_COHORT);}\n')
commands=subprocess.check_output(['ninja','-C',str(R/'build/v3-current-e0-20261021/Selected/Debug'),'-t','commands','papacc_phase6_memory_census_test'],text=True)
c=next(x for x in commands.splitlines() if ' -c ' in x and 'phase6_memory_census_test.c' in x)
c=re.sub(r'/Fo\S+', lambda m:'/Fo'+str(S/'probe.obj'),c);c=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(S/'probe.pdb'),c);c=c.replace(str(R/'tests/phase6_memory_census_test.c').replace('\\','/'),str(S/'probe.c'))
# CMake's command may use backslash path spelling.
c=c.rsplit(' -c ',1)[0]+' -c '+str(S/'probe.c')
(S/'probe.cmd').write_text('@echo off\ncall "C:\\Program Files (x86)\\Microsoft Visual Studio\\18\\BuildTools\\VC\\Auxiliary\\Build\\vcvars64.bat"\n'+c+'\nexit /b %errorlevel%\n')
print(c[-220:])

