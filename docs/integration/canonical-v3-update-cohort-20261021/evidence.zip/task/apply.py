from pathlib import Path
import hashlib,json
R=Path(r'C:\Projetos\PapinhoAccelerator');S=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S/'operations.json')=='2a12088603f09ca2f6a2b106905675f94d49c4c90b20ebf288c50eb89906092a'
assert sha(S/'prepatch-lifetime-capacity-proof.json')=='a27b3a220c6c5150721c6f9e41192162a618435d6eec52592031973d68fc5f70'
assert (S/'probe.obj').exists()
ops=json.loads((S/'operations.json').read_text())
for x in ops:assert (sha(R/x['path']) if (R/x['path']).exists() else None)==x['before'];assert sha(S/'staged'/x['path'])==x['after']
for x in ops:
 p=R/x['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/'staged'/x['path']).read_bytes())
print('9_EXACT_APPROVED_COHORT_OPERATIONS_APPLIED_PREPATCH_GATE_VERIFIED')
