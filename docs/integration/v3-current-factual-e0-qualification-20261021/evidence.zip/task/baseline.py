import pathlib,json,subprocess,hashlib
root=pathlib.Path(r'C:\Projetos\PapinhoAccelerator')
stage=pathlib.Path(r'C:\Users\tobias\AppData\Local\Temp\pacc-v3-current-e0-20261021')
stage.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
base={}
for name,path in [('Accelerator',root),('Browser',pathlib.Path(r'C:\Projetos\PapinhoBrowser'))]:
 def git(*a):return subprocess.check_output(['git','-C',str(path),*a],text=True)
 files=git('ls-files','--cached','--others','--exclude-standard','--','.',':(exclude)build',':(exclude)node_modules').splitlines()
 hashes={f:sha(path/f) for f in sorted(set(files)) if (path/f).is_file() and not f.startswith(('.git/','.agents/','.codex/','.aws/'))}
 base[name]={'root':str(path),'HEAD':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'status':git('status','--porcelain=v1','--','.',':(exclude)build',':(exclude)node_modules'),'hashes':hashes}
(stage/'baseline.json').write_text(json.dumps(base,indent=2),encoding='utf8')
print(json.dumps({k:{'HEAD':v['HEAD'],'branch':v['branch'],'files':len(v['hashes']),'wip_lines':len(v['status'].splitlines())} for k,v in base.items()}))

