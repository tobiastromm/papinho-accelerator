from pathlib import Path
import json,hashlib
r=Path(r'C:\Projetos\PapinhoAccelerator');s=Path(__file__).parent;m=r/'docs/integration/kind8-dispatch-after-g7-20261021/final-manifest.json';items=json.loads(m.read_text())
for f,v in items.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==v['sha256'],f
(s/'prior-manifest-verification.json').write_text(json.dumps({'entries':len(items),'mismatches':[],'manifest_sha256':hashlib.sha256(m.read_bytes()).hexdigest()},indent=2));print('33 prior artifact hashes match')
