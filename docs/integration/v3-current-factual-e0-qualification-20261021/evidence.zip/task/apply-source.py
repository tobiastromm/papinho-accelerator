from pathlib import Path
import json,hashlib
r=Path(r'C:\Projetos\PapinhoAccelerator');s=Path(__file__).parent;p=s/'source-operations.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='c7f5546b298799faaae0ea0a1c6cbb414582bd240e346868bd9fad3640ad6c73'
ops=json.loads(p.read_text())
for o in ops:
 f=r/o['path'];assert (hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None)==o['before'];assert hashlib.sha256((s/'staged'/o['path']).read_bytes()).hexdigest()==o['after']
for o in ops:(r/o['path']).write_bytes((s/'staged'/o['path']).read_bytes())
print('6_EXACT_APPROVED_DATA_CORRELATION_NEGATIVE_PREFLIGHT_OPERATIONS_APPLIED')
