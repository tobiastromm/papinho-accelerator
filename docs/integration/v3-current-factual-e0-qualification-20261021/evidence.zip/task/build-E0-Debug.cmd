@echo off
set VSLANG=1033
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
cmake -S tests/shared_evidence -B build/v3-current-e0-20261021/E0/Debug -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_FLAGS=/WX
if errorlevel 1 exit /b %errorlevel%
cmake --build build/v3-current-e0-20261021/E0/Debug
if errorlevel 1 exit /b %errorlevel%
ctest --test-dir build/v3-current-e0-20261021/E0/Debug --output-on-failure
exit /b %errorlevel%
