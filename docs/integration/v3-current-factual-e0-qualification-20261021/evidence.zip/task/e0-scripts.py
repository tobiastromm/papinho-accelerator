from pathlib import Path
s=Path(__file__).parent
for mode in ['Debug','Release']:
 t='@echo off\nset VSLANG=1033\ncall "C:\\Program Files (x86)\\Microsoft Visual Studio\\18\\BuildTools\\VC\\Auxiliary\\Build\\vcvars64.bat"\nif errorlevel 1 exit /b %errorlevel%\n'
 t+=f'cmake -S tests/shared_evidence -B build/v3-current-e0-20261021/E0/{mode} -G Ninja -DCMAKE_BUILD_TYPE={mode} -DCMAKE_C_FLAGS=/WX\nif errorlevel 1 exit /b %errorlevel%\n'
 t+=f'cmake --build build/v3-current-e0-20261021/E0/{mode}\nif errorlevel 1 exit /b %errorlevel%\nctest --test-dir build/v3-current-e0-20261021/E0/{mode} --output-on-failure\nexit /b %errorlevel%\n'
 (s/f'build-E0-{mode}.cmd').write_text(t,encoding='utf8')
