from pathlib import Path
import json,hashlib,subprocess,re,zipfile
R=Path(r'C:\Projetos\PapinhoAccelerator'); S=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((S/'baseline.json').read_text());ops=json.loads((S/'source-operations.json').read_text());repair=json.loads((S/'repair-operation.json').read_text());expected={x['path']:x['after'] for x in ops};expected[repair['path']]=repair['after']
check={}
for name,v in b.items():
 p=Path(v['root']); diff=[f for f,h in v['hashes'].items() if not (p/f).exists() or sha(p/f)!=h];allowed=expected if name=='Accelerator' else {}
 assert all(f in allowed and sha(p/f)==allowed[f] for f in diff),(name,diff)
 assert subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()==v['HEAD']
 check[name]={'baseline_files':len(v['hashes']),'approved_changed':diff,'unexpected_changes':[], 'HEAD':v['HEAD'],'WIP_preserved':True}
results=[]
for profile,cfg,log,n in [('Selected','Debug','Selected-Debug-final.log',20),('Selected','Release','Selected-Release-final.log',20),('Legacy','Debug','Legacy-Debug-initial.log',16),('Legacy','Release','Legacy-Release-initial.log',16),('E0','Debug','E0-Debug.log',1),('E0','Release','E0-Release.log',1)]:
 t=(S/log).read_text(encoding='utf8',errors='replace');assert f'0 tests failed out of {n}' in t;warnings=re.findall(r'\bwarning\s+[A-Z]+\d+\s*:',t,re.I);assert not warnings
 results.append({'profile':profile,'configuration':cfg,'tests_passed':n,'warnings':0,'log':log})
native=json.loads((R/'build/v3-current-e0-20261021/native/native-results.json').read_text());assert len(native)==16 and all(x['exit']==0 for x in native)
(S/'verification.json').write_text(json.dumps({'baseline':check,'builds':results,'native':native},indent=2),encoding='utf8')
D=Path('docs/integration/v3-current-factual-e0-qualification-20261021'); out=S/'docs-staged';out.mkdir(exist_ok=True)
files={}
def doc(name,text):files[str(D/name)]=text.encode('utf8')
doc('closeout.md','''# V3 CURRENT / E0 — conclusão parcial

CURRENT_TASK_COMPLETED=NO

Implementadas correlação DATA CP3/revisão/predecessor/A/P/I sob o mesmo pin e consulta negativa de prontidão na root canônica. O preflight usa os guards existentes de CURRENT; mesmo se a correlação DATA passar, retorna NOT_SUPPORTED. Não produz evidência, lease, confiança ou publicação.

A qualificação positiva permanece PENDING_EXTERNAL_ENVIRONMENT, conforme decisão do owner: não existe instalação CURRENT v3 qualificada disponível. Também faltam integração nativa de commit/publicação CP3, predecessor completo protegido e proveniência factual de aprovação/status da delegação. Digest e metadados de fixture não suprem essas obrigações.

Seis builds finais MSVC Debug/Release: Selected e Legacy mais E0/M1 C90 isolado, sem warnings. 72 suítes principais + 2 isoladas e 16 casos nativos locais passaram. Os casos positivos DATA são sintéticos; casos nativos de filesystem/worker não qualificam CURRENT v3. Duas falhas iniciais Selected por ordem Windows/Winsock dos includes foram preservadas e corrigidas mediante aprovação exata.

Fixo Selected 1.943.680 bytes; Legacy 1.790.872, inalterados. Nenhum campo/buffer fixo, heap, thread, handle ou pin adicionado. Stack transitivo/provider/kernel continuam UNKNOWN. Cenário conservador anterior completo 3.742.625 excede 3 MiB; não é pico medido nem reserva. ED11 PARTIAL; ativação DENY.

[Prova e handoff](current-and-source-proof.md) · [Validação](validation.json) · [ED11](ed11-census.json) · [Hashes](final-manifest.json) · [Evidências](evidence.zip)

```ini
V3_CURRENT_BINDING=DATA_CORRELATION_AND_NEGATIVE_PREFLIGHT_ONLY
E0_E8_FACTUAL_SOURCE=DENY
KIND8_DISPATCH=IMPLEMENTED_PUBLIC_DATA
G7_LIFETIME=PASS_SCOPED_DATA
M1_TRUST=DENY_UNTIL_FACTUAL_SOURCE
PAPACC_INSTALL=DENY
AUTOMATIC_ENROLLMENT=DENY
CURRENT_PUBLICATION=DENY
SIGNATURE_AUTHORITY=DENY
AUTHORITATIVE_RECOVERY=DENY
ED11_TOTAL_STATUS=PARTIAL
CLIENT_ADMISSION=DISABLED
SITE_TLS_ADMISSION=DENY
ED11_ADMISSION=DENY
NETWORK_TESTS=NOT_RUN
BROWSER_CHANGED=NO
PST_CHANGED=NO
PACC_WIRE_CHANGED=NO
PRODUCTION_PIN=0.6.4
WIP_PRESERVED=YES
FIRST_UNRESOLVED_DIVERGENCE=NATIVE_V3_COMMIT_CP3_PUBLICATION_AND_PROTECTED_FULL_PREDECESSOR_SOURCE_UNQUALIFIED
NEXT=MANUAL_PACKAGE_FACTUAL_TRUST_AND_END_TO_END_QUALIFICATION
```
''')
doc('current-and-source-proof.md','''# Correlação DATA e limite da fonte factual

## Matriz de conformidade

| Obrigação | Evidência implementada | Limite |
|---|---|---|
| Identidade/revisão/CP3 | Mesmo owner, pin, serial; imagem inteira committed igual ao backing; CP3 magic/versão/domínio/R/predecessor/A/P/I iguais ao slot | Correlação DATA, não prova de origem nativa |
| CURRENT | Preflight exige singleton canônico, preparação válida, Stop ausente e configuration_current existente | Fonte positiva indisponível; nunca retorna OK |
| Predecessor completo | Divergência do predecessor CP3 rejeitada | Digest/revisão não provam composição anterior completa protegida |
| G7 | Borrow canônico revalida integridade e lifetime existentes | Não cria novo owner/pin ou autoridade |
| E0–E8 | SOURCE_ABSENT permanece; acquire DENIED sem lease; RELEASE_INVALID sem efeito | Nenhum produtor/opaque concretizado |
| Stop/retenção | Novos borrows negados; borrow já protegido continua até unpin/quiescência | Nenhuma liberação por timeout |
| Compatibilidade | Leitores históricos/formatos/guards CURRENT preservados; regressões existentes | Não implementa commit v3 ou migração |
| M1 | Testes isolados de sequência e ausência da fonte | TRUST negado; KDF não autorizado |

## Código delimitado

`papacc_configuration_v3_checkpoint_match_data` somente compara imagem retida com committed e CP3 com metadados da revisão sob lock e pin. Recusa tamanhos maiores que o armazenamento existente; não trunca nem amplia buffers. Só aceita estado publicado, sem pending, prepared, committed_pending ou recovery. Mesmo OK não comprova commit nativo, CURRENT, aprovação ou frescor.

`papacc_server_launcher_configuration_v3_evidence_preflight` opera somente na root canônica e exige o CURRENT já existente. Propaga falhas DATA e termina NOT_SUPPORTED mesmo após correlação completa. Nenhum borrow ou lease sai dessa função. Nenhuma operação nativa nova ocorre dentro de acquire E0–E8.

## Handoff necessário antes de qualquer fonte positiva

1. Integrar commit v3 e publicação CP3 no worker/transação existentes, com resultado factual e CAS; não inferir sucesso de UNKNOWN. A capacidade atual de imagem é 28.960 e máximo v3 30.592; eventual ajuste de 4.896 para três imagens ainda não foi aplicado.
2. Proteger o predecessor completo v2/v3/checkpoint e seu histórico no owner existente durante PREPARE→RESULT. pending.previous mutável não é prova de lifetime por si só. Separar captura de candidato de consumo de snapshot publicado sem inventar CURRENT candidato.
3. Obter proveniência administrativa de delegação, disposição/revogação/validade e revisão policy/issuer sob pins coerentes. PDG decodificado, RSA e domínio hash são DATA, não autorização.
4. Executar qualificação integrada posteriormente em instalação Windows autorizada, pela cerimônia accepted e mesma root/worker. CURRENT ausente/obsoleto, Stop, UNKNOWN e ausência de evidência devem negar. Não inicializar store para suprir esta tarefa.
5. Só após essas provas preparar referências factuais já protegidas para acquire síncrono E0–E8; owner anterior conserva ownership, borrow é explícito e RELEASE_INVALID não tenta liberação. Confirmação independente e autorização local continuam no Browser, sem acesso à root privada.

Não houve nova decisão normativa, mudança de formatos ou API compartilhada. As autoridades F1–F5/G0–G7, E0–E8, M1, root/C8 e Model E permanecem limitadoras.
''')
base=json.loads((R/'docs/integration/kind8-dispatch-after-g7-20261021/ed11-census.json').read_text())
base.update({'task':'V3_CURRENT_FACTUAL_E0','new_fixed_bytes':0,'Selected_fixed_before_after':1943680,'Legacy_fixed_before_after':1790872,'new_helper_local_borrow':'88 bytes x64 plus compiler frame/alignment, not a permanent reservation','new_preflight':'no output buffer/allocation/pin/lease; nested helper stack must coexist','full_transitive_stack':'UNKNOWN_NOT_ZERO; prior dispatcher frames do not bound new call chain','operational_ED11_total':'PARTIAL','positive_E0_allocation':0,'full_activation':'DENY','memory_moved_to_escape_accounting':False})
doc('ed11-census.json',json.dumps(base,indent=2)+'\n')
doc('validation.json',json.dumps({'builds':results,'native_cases':native,'main_suites':72,'isolated_E0_M1_suites':2,'native_cases_passed':16,'new_test_checks_per_configuration':72,'initial_failures':'Selected Debug/Release include order only; logs preserved; exact approved repair','synthetic_positive_authority':False,'native_positive_CURRENT':False,'VC6_NT4_box_ISA':'NOT_QUALIFIED_BY_THIS_RUN','network':'NOT_RUN','baseline':check},indent=2)+'\n')
doc('approval-and-preimages.md','''# Aprovação exata e preimagens

Fonte: operations SHA256 c7f5546b298799faaae0ea0a1c6cbb414582bd240e346868bd9fad3640ad6c73, aprovação/aplicação oficial via exec escalado, chunk 66091c. Seis operações; preimagens e patch no evidence.zip.

Correção exclusiva de ordem dos includes no teste: operations SHA256 1aca969b5e7449f0668f366478a92502de5712a4848dfd872e649707e642e5fb, aprovação/aplicação oficial chunk cf1cb3. Repair pre/postimages e patch preservados. Nenhuma negativa foi contornada. Estes identificadores são registros da execução, não atestação externa assinada.

Documentação e append de capability submetidos separadamente por manifesto exato antes de aplicação. ADRs accepted e propostas históricas não alterados.
''')
z=S/'evidence.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as a:
 for p in S.iterdir():
  if p.is_file() and p.name not in ('evidence.zip',):a.write(p,'task/'+p.name)
 for p in (R/'build/v3-current-e0-20261021').rglob('LastTest.log'):a.write(p,str(p.relative_to(R)))
 for p in (R/'build/v3-current-e0-20261021/native').glob('*.log'):a.write(p,'native/'+p.name)
files[str(D/'evidence.zip')]=z.read_bytes()
cap='docs/capabilities/client-pairing.md';files[cap]=(R/cap).read_bytes()+('''\n\n### CURRENT v3 / E0 — correlação DATA e preflight negativo — 2026-10-21

A mesma root possui agora correlação CP3/R/predecessor/A/P/I sob pin e preflight negativo usando os guards CURRENT existentes. Mesmo com correlação DATA, não há fonte E0 positiva: commit/publicação CP3 nativos, predecessor completo protegido e proveniência administrativa ainda não qualificados; CURRENT factual permanece PENDING_EXTERNAL_ENVIRONMENT. Nenhum lease, pin, owner ou confiança fabricado. Seis builds finais sem warnings,72 suítes principais+2 E0/M1 e16 casos nativos locais passam, sem qualificação positiva CURRENT. Fixo Selected1943680/Legacy1790872 inalterado; stack transitivo/provider/kernel UNKNOWN e ED11 PARTIAL. Browser/PST/wire/produção0.6.4 e gates DENY preservados. [Prova, testes, hashes e handoff](../integration/v3-current-factual-e0-qualification-20261021/closeout.md).
''').encode('utf8')
manifest={'task':'PACC-PHASE6-V3-CURRENT-FACTUAL-E0-QUALIFICATION-1','files':[]}
for f in expected:manifest['files'].append({'path':f,'sha256':sha(R/f)})
for f,data in files.items():manifest['files'].append({'path':f,'sha256':hashlib.sha256(data).hexdigest()})
files[str(D/'final-manifest.json')]=(json.dumps(manifest,indent=2)+'\n').encode()
operations=[]
for f,data in files.items():
 p=out/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);operations.append({'path':f,'before':sha(R/f) if (R/f).exists() else None,'after':sha(p)})
(S/'docs-operations.json').write_text(json.dumps(operations,indent=2),encoding='utf8')
print('DOCUMENTATION_OPERATIONS_SHA256',sha(S/'docs-operations.json'));print('FILES',len(operations));print(json.dumps(check))
