from pathlib import Path
import zipfile
s=Path(__file__).parent;r=Path(r'C:\Projetos\PapinhoAccelerator')
for profile in ['Selected','Legacy']:
 for mode in ['Debug','Release']:
  with zipfile.ZipFile(r/'docs/integration/kind8-dispatch-after-g7-20261021/implementation-evidence.zip') as z:t=z.read(f'build-{profile}-{mode}.cmd').decode('utf8')
  t=t.replace('build/kind8-after-g7-20261021/','build/v3-current-e0-20261021/')
  if profile=='Selected':t=t.replace('--target papacc_kind8_dispatch_model_test','--target papacc_v3_current_negative_test papacc_kind8_dispatch_model_test')
  t=t.replace('papacc.kind8.dispatch"','papacc.kind8.dispatch|papacc.v3.current_negative"')
  (s/f'build-{profile}-{mode}.cmd').write_text(t,encoding='utf8')
