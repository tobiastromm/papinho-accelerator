from pathlib import Path
import json,hashlib
s=Path(__file__).parent;r=Path(r'C:\Projetos\PapinhoAccelerator');p=s/'repair-operation.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='1aca969b5e7449f0668f366478a92502de5712a4848dfd872e649707e642e5fb'
o=json.loads(p.read_text());f=r/o['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==o['before'];assert hashlib.sha256((s/'repair-postimage.c').read_bytes()).hexdigest()==o['after'];f.write_bytes((s/'repair-postimage.c').read_bytes());print('EXACT_TEST_INCLUDE_ORDER_REPAIR_APPLIED')
