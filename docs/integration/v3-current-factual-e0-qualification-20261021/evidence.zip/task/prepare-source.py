from pathlib import Path
import json,hashlib,difflib,zipfile
r=Path(r'C:\Projetos\PapinhoAccelerator');s=Path(__file__).parent;d=s/'staged';d.mkdir(exist_ok=True);ops=[]
def put(f,x):
 p=r/f;old=p.read_bytes() if p.exists() else None;q=d/f;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(x);ops.append({'path':f,'before':hashlib.sha256(old).hexdigest() if old else None,'after':hashlib.sha256(x).hexdigest()})
f='apps/server/server_configuration_commit_win32.h';x=(r/f).read_bytes();a=b'PAPACC_RESULT papacc_configuration_v3_borrow_data(PAPACC_CONFIGURATION_COMMIT *,\r\n const PAPACC_CONFIG_PIN *,PAPACC_CONFIG_V3_BORROW *);';assert a in x
b=a+b'''
/* Same-pin DATA equation only: stored packet/CP3 vs slot R/predecessor/A/P/I.
 * OK is NOT native commit, full-predecessor approval, CURRENT or E0 evidence.
 * No output borrow/pin/lease, mutation, allocation or publication. */
PAPACC_RESULT papacc_configuration_v3_checkpoint_match_data(
 PAPACC_CONFIGURATION_COMMIT *,const PAPACC_CONFIG_PIN *);'''.replace(b'\n',b'\r\n');put(f,x.replace(a,b,1))
f='apps/server/server_configuration_v3_backings_win32.inc';x=(r/f).read_bytes()+r'''
/* Correlation of already protected DATA, deliberately not a CURRENT factory. */
PAPACC_RESULT papacc_configuration_v3_checkpoint_match_data(
 PAPACC_CONFIGURATION_COMMIT *o,const PAPACC_CONFIG_PIN *pin)
{
 PAPACC_CONFIG_V3_BORROW borrow;PAPACC_CONFIG_SLOT *slot;const PAPACC_U8 *cp;
 PAPACC_RESULT result;
 if(!owner(o)||!pin)return PAPACC_RESULT_INVALID_ARGUMENT;
 result=papacc_configuration_v3_borrow_data(o,pin,&borrow);if(result!=PAPACC_RESULT_OK)return result;
 EnterCriticalSection(&o->lock);result=PAPACC_RESULT_INVALID_STATE;
 if(!o->published||o->prepared||o->committed_pending||pending_blocks(o)||o->recovery_selected||
 pin->index!=o->current||!o->issuer_snapshot_valid[pin->index])goto done;
 slot=&o->slots[pin->index];
 if(!slot->context_epoch||!slot->operational_epoch||!slot->issuer_revision)goto done;
 if(borrow.packet_bytes>sizeof(o->committed)){result=PAPACC_RESULT_NOT_SUPPORTED;goto done;}
 if(o->committed_bytes!=borrow.packet_bytes||memcmp(o->committed,borrow.packet,borrow.packet_bytes))goto done;
 cp=borrow.packet+v3b32(borrow.packet+56);
 if(memcmp(cp,"PACR8CP3",8)||cp[8]!=3U||cp[9]||
 memcmp(cp+16,slot->view.domain,32)||v3b64(cp+48)!=slot->view.revision||
 v3b64(cp+56)!=slot->view.predecessor||v3b64(cp+64)!=slot->context_epoch||
 v3b64(cp+72)!=slot->operational_epoch||v3b64(cp+80)!=slot->issuer_revision)goto done;
 result=PAPACC_RESULT_OK; /* DATA only; no provenance/freshness/fencing claim */
done:LeaveCriticalSection(&o->lock);return result;
}
'''.replace('\n','\r\n').encode();put(f,x)
f='apps/server/server_launcher_owner_win32.h';x=(r/f).read_bytes();a=b'PAPACC_BOOL papacc_server_launcher_configuration_current(PAPACC_SERVER_LAUNCHER_OWNER_WIN32*,const PAPACC_ROOT_CURRENT_PIN*);';assert a in x
b=a+b'''
#if defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_OFFLINE_D3_WORKER)
/* Read-only negative readiness gate under the SAME canonical root CURRENT.
 * A DATA checkpoint match cannot supply native v3 commit/predecessor/policy
 * provenance. No source/lease/observation is produced; currently never OK. */
PAPACC_RESULT papacc_server_launcher_configuration_v3_evidence_preflight(
 PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *,const PAPACC_ROOT_CURRENT_PIN *);
#endif'''.replace(b'\n',b'\r\n');put(f,x.replace(a,b,1))
f='apps/server/server_configuration_root_transaction_win32.inc';x=(r/f).read_bytes();a=b'static int interface_report_overlaps(';assert a in x
b=r'''#if defined(PAPACC_ED11_WINDOWS_3MIB) && defined(PAPACC_OFFLINE_D3_WORKER)
PAPACC_RESULT papacc_server_launcher_configuration_v3_evidence_preflight(
 PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *o,const PAPACC_ROOT_CURRENT_PIN *pin)
{
 PAPACC_RESULT data_result;
 if(o!=&root||!pin)return PAPACC_RESULT_INVALID_ARGUMENT;
 if(!preparation_owned(o)||papacc_server_console_win32_stop_requested()==PAPACC_TRUE||
 papacc_server_launcher_configuration_current(o,pin)!=PAPACC_TRUE)return PAPACC_RESULT_INVALID_STATE;
 data_result=papacc_configuration_v3_checkpoint_match_data(&o->configuration_commit,&pin->pin);
 if(data_result!=PAPACC_RESULT_OK)return data_result;
 /* Native v3 commit/CP3 publication and full protected predecessor/disposition
  * provenance have no qualified producer yet. Do not infer them from DATA,
  * epochs or the old-format CURRENT guard. No opaque E0 object is fabricated. */
 return PAPACC_RESULT_NOT_SUPPORTED;
}
#endif
'''.replace('\n','\r\n').encode();put(f,x.replace(a,b+a,1))
f='CMakeLists.txt';x=(r/f).read_bytes()+b'''
if(PAPACC_ENABLE_OFFLINE_D3_WORKER AND PAPACC_ENABLE_WINDOWS_3MIB_MANAGED_PROFILE)
 add_executable(papacc_v3_current_negative_test tests/v3_current_negative_win32_test.c apps/server/server_config_root8_data_win32.c src/provisioning/shared_structure/trust_unavailable.c)
 target_compile_definitions(papacc_v3_current_negative_test PRIVATE PAPACC_OFFLINE_D3_WORKER=1 PAPACC_V3_BACKING_FIXTURE=1 PAPACC_KIND8_DISPATCH_FIXTURE=1)
 target_include_directories(papacc_v3_current_negative_test PRIVATE ${PAPACC_GRAPH_INCLUDE_DIRS} src/config src/issuer src/provisioning/shared_structure apps/server)
 target_link_libraries(papacc_v3_current_negative_test PRIVATE papacc_config_root8 papacc_server_run_win32 papacc_config_binding papacc_issuer papacc_root8_signer_data crypt32)
 papacc_enable_warnings(papacc_v3_current_negative_test)
 papacc_stage_pst_runtime(papacc_v3_current_negative_test)
 add_test(NAME papacc.v3.current_negative COMMAND papacc_v3_current_negative_test "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/security/ca.der.b64")
endif()
'''.replace(b'\n',b'\r\n');put(f,x)
x=r'''/* CP3 DATA relation and actual singleton CURRENT-absent preflight.
 * No store/commit/publication, signing, source factory or synthetic lease. */
#include "v3_backing_win32_test.c"
#include "server_c8_private_storage_layout_win32.h"
#include "trust.h"
static PAPACC_SERVER_NETWORK empty_network;
static PAPACC_SERVER_CONFIG empty_config=PAPACC_SERVER_CONFIG_INITIALIZER;
static PAPACC_LOGGER silent_logger={NULL,NULL,PAPACC_LOG_LEVEL_OFF};
static int current_negative(const char *ca_path)
{
 PAPACC_CONFIG_PIN pin={0};PAPACC_ROOT_CURRENT_PIN root_pin={0};PAPACC_SERVER_LAUNCHER_OWNER_WIN32 *canonical=NULL;
 PAPACC_CONFIG_V3_BORROW borrow;PAPACC_ISSUER_WINDOWS_WORKSPACE capture;
 PAPACC_U8 key_digest[32];PAPACC_SIZE ca_bytes;char path[MAX_PATH];DWORD n;
 const SP_TRUST_LEASE *lease=NULL;
 n=GetFullPathNameA("current-v3-MODEL-NO-STORE",MAX_PATH,path,NULL);CHECK(n&&n<MAX_PATH);
 CHECK(papacc_configuration_commit_init03(&owner,path)==PAPACC_RESULT_OK);
 CHECK(load_ca(ca_path,&ca_bytes,key_digest));CHECK(setup3(1,1,1));CHECK(bind_ca_data(key_digest));CHECK(cp3());
 config_init(0,2);owner.slots[1].view=view;owner.slots[1].serial=++owner.next_serial;
 owner.pending=1;owner.prepared=1;memcpy(owner.domain,e3+72,32);
 memset(&capture,0,sizeof(capture));capture.bytes=arena;capture.capacity=sizeof(arena);
 CHECK(papacc_configuration_v3_capture_data(&owner,e3,z3,ca_der,ca_bytes,&capture,component3,NULL)==PAPACC_RESULT_OK);
 /* MODEL metadata and bytes for DATA equations only. No native file/current. */
 owner.prepared=0;owner.current=1;owner.published=1;
 owner.slots[1].context_epoch=18;owner.slots[1].operational_epoch=9;owner.slots[1].issuer_revision=r64(e3+120);
 owner.issuer_snapshot_valid[1]=1;memcpy(owner.issuer_snapshots[1],e3+r32(e3+48)+8192,8192);
 CHECK(z3<=sizeof(owner.committed));memcpy(owner.committed,e3,z3);owner.committed_bytes=(DWORD)z3;
 CHECK(papacc_configuration_pin(&owner,&pin,&view)==PAPACC_RESULT_OK);
 CHECK(papacc_configuration_v3_borrow_data(&owner,&pin,&borrow)==PAPACC_RESULT_OK);
 CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)==PAPACC_RESULT_OK);
 owner.committed[600]^=1;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.committed[600]^=1;
 owner.committed_bytes--;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.committed_bytes++;
 owner.slots[1].context_epoch++;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.slots[1].context_epoch--;
 owner.slots[1].operational_epoch++;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.slots[1].operational_epoch--;
 owner.slots[1].issuer_revision++;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.slots[1].issuer_revision--;
 owner.slots[1].view.predecessor++;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.slots[1].view.predecessor--;
 pin.ticket++;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);pin.ticket--;
 owner.authority_lost=1;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.authority_lost=0;
 owner.unresolved=1;CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);owner.unresolved=0;
 /* Never use the diagnostic commit owner as the actual root singleton. */
 CHECK(papacc_server_launcher_configuration_v3_evidence_preflight(NULL,&root_pin)!=PAPACC_RESULT_OK);
 CHECK(sp_trust_acquire(NULL,NULL,NULL,&lease)==SP_TRUST_DENIED&&!lease);
 CHECK(sp_trust_release(NULL)==SP_TRUST_RELEASE_INVALID);
 CHECK(papacc_configuration_stop(&owner)==PAPACC_RESULT_OK);
 CHECK(papacc_configuration_v3_checkpoint_match_data(&owner,&pin)!=PAPACC_RESULT_OK);
 CHECK(!memcmp(borrow.packet,e3,z3));CHECK(papacc_configuration_finish(&owner)!=PAPACC_RESULT_OK);
 CHECK(papacc_configuration_unpin(&owner,&pin,0)==PAPACC_RESULT_OK);
 CHECK(papacc_configuration_finish(&owner)==PAPACC_RESULT_OK);
 /* Real canonical singleton, no preparation/store/CURRENT/evidence fabricated. */
 empty_config.control_port=4433;empty_config.bind_selection.mode=PAPACC_BIND_SELECTION_ALL_INTERFACES;
 CHECK(papacc_server_launcher_owner_acquire(&empty_network,&empty_config,&silent_logger,&canonical)==PAPACC_RESULT_OK);
 CHECK(papacc_server_launcher_configuration_v3_evidence_preflight(canonical,NULL)!=PAPACC_RESULT_OK);
 CHECK(papacc_server_launcher_configuration_v3_evidence_preflight(canonical,&root_pin)!=PAPACC_RESULT_OK);
 root_pin.invocation=canonical->invocation+1;CHECK(papacc_server_launcher_configuration_v3_evidence_preflight(canonical,&root_pin)!=PAPACC_RESULT_OK);
 CHECK(!canonical->configuration_commit.initialized&&!canonical->configuration_preparation.normative_committed&&!canonical->configuration_preparation.administrative_published);
 CHECK(sp_trust_acquire(NULL,NULL,NULL,&lease)==SP_TRUST_DENIED&&!lease);
 CHECK(papacc_server_launcher_owner_finish(canonical,&empty_network,PAPACC_TRUE)==PAPACC_RESULT_OK);
 printf("PASS %u V3_CHECKPOINT_DATA_ONLY_CANONICAL_CURRENT_ABSENT_E0_DENIED NO_STORE_NO_PUBLICATION_NO_TRUST\n",checks);return 1;
}
int main(int argc,char **argv){return argc==2&&current_negative(argv[1])?0:1;}
'''
put('tests/v3_current_negative_win32_test.c',x.replace('\n','\r\n').encode());(s/'source-operations.json').write_text(json.dumps(ops,indent=2));patch=''
with zipfile.ZipFile(s/'preimages.zip','w',zipfile.ZIP_DEFLATED) as z:
 for o in ops:
  f=r/o['path'];old=f.read_text().splitlines(True) if f.exists() else []
  if f.exists():z.write(f,o['path'])
  patch+=''.join(difflib.unified_diff(old,(d/o['path']).read_text().splitlines(True),fromfile='a/'+o['path'],tofile='b/'+o['path']))
(s/'exact-source.patch').write_text(patch,encoding='utf8');print(json.dumps({'operations':len(ops),'sha256':hashlib.sha256((s/'source-operations.json').read_bytes()).hexdigest()}))
